package com.example

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.Operator
import com.example.data.model.PackageType
import com.example.data.model.UserRole
import com.example.data.repository.TelecomRepository
import com.example.ui.components.AppBottomNavBar
import com.example.ui.components.AppHeader
import com.example.ui.screens.AddBalanceScreen
import com.example.ui.screens.AdminScreen
import com.example.ui.screens.AuthScreen
import com.example.ui.screens.HistoryScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.PackageScreen
import com.example.ui.screens.ProfileScreen
import com.example.ui.screens.RechargeScreen
import com.example.ui.screens.ServicesScreen
import com.example.ui.theme.EmeraldContainer
import com.example.ui.theme.EmeraldDark
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.MasumTelecomTheme
import com.example.ui.theme.StatusFailed
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun MasumTelecomApp() {
    MasumTelecomTheme {
        val currentUser by TelecomRepository.currentUser.collectAsStateWithLifecycle()
        val users by TelecomRepository.users.collectAsStateWithLifecycle()
        val packages by TelecomRepository.packages.collectAsStateWithLifecycle()
        val transactions by TelecomRepository.transactions.collectAsStateWithLifecycle()
        val addBalanceRequests by TelecomRepository.addBalanceRequests.collectAsStateWithLifecycle()
        val notices by TelecomRepository.notices.collectAsStateWithLifecycle()
        val apiConfig by TelecomRepository.apiConfig.collectAsStateWithLifecycle()
        val isBengali by TelecomRepository.isBengali.collectAsStateWithLifecycle()

        var currentScreen by remember { mutableStateOf("home") }
        var showAdminPanel by remember { mutableStateOf(false) }
        var showAdminPinDialog by remember { mutableStateOf(false) }
        var showNoticesDialog by remember { mutableStateOf(false) }

        var selectedOperatorForRecharge by remember { mutableStateOf<Operator?>(null) }
        var initialPackageType by remember { mutableStateOf(PackageType.DRIVE) }
        var initialServiceTab by remember { mutableStateOf("bill_pay") }

        // BackHandler for sub-screens
        if (showAdminPanel) {
            BackHandler {
                showAdminPanel = false
            }
        } else if (currentScreen != "home") {
            BackHandler {
                currentScreen = "home"
            }
        }

        // 1. Auth Flow: If not logged in, show AuthScreen
        if (currentUser == null) {
            AuthScreen(
                isBengali = isBengali,
                onAuthSuccess = { user ->
                    currentScreen = "home"
                }
            )
            return@MasumTelecomTheme
        }

        val user = currentUser!!

        // 2. Admin Panel Screen
        if (showAdminPanel) {
            AdminScreen(
                adminUser = user,
                users = users,
                packages = packages,
                transactions = transactions,
                addBalanceRequests = addBalanceRequests,
                notices = notices,
                apiConfig = apiConfig,
                isBengali = isBengali,
                onExitAdmin = { showAdminPanel = false }
            )
            return@MasumTelecomTheme
        }

        // 3. Main Dealer Application Scaffold
        Scaffold(
            topBar = {
                AppHeader(
                    title = "MASUM TELECOM",
                    user = user,
                    isBengali = isBengali,
                    onToggleLanguage = { TelecomRepository.toggleLanguage() },
                    onAdminClick = {
                        if (user.role == UserRole.ADMIN) {
                            showAdminPanel = true
                        } else {
                            showAdminPinDialog = true
                        }
                    },
                    onProfileClick = { currentScreen = "profile" },
                    onNoticeClick = { showNoticesDialog = true }
                )
            },
            bottomBar = {
                AppBottomNavBar(
                    selectedTab = if (currentScreen in listOf("home", "recharge", "packages", "history", "services")) currentScreen else "home",
                    onTabSelected = { tab -> currentScreen = tab },
                    isBengali = isBengali
                )
            }
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                when (currentScreen) {
                    "home" -> HomeScreen(
                        user = user,
                        notices = notices,
                        transactions = transactions,
                        isBengali = isBengali,
                        onNavigateToRecharge = {
                            selectedOperatorForRecharge = null
                            currentScreen = "recharge"
                        },
                        onNavigateToPackages = { isDrive ->
                            initialPackageType = if (isDrive) PackageType.DRIVE else PackageType.REGULAR
                            currentScreen = "packages"
                        },
                        onNavigateToAddBalance = { currentScreen = "add_balance" },
                        onNavigateToHistory = { currentScreen = "history" },
                        onNavigateToServices = { service ->
                            initialServiceTab = service
                            currentScreen = "services"
                        },
                        onSelectOperator = { op ->
                            selectedOperatorForRecharge = op
                            currentScreen = "recharge"
                        },
                        onNoticeClick = { showNoticesDialog = true }
                    )

                    "recharge" -> RechargeScreen(
                        user = user,
                        isBengali = isBengali,
                        initialOperator = selectedOperatorForRecharge,
                        onNavigateBack = { currentScreen = "home" }
                    )

                    "packages" -> PackageScreen(
                        user = user,
                        packages = packages,
                        isBengali = isBengali,
                        initialPackageType = initialPackageType
                    )

                    "add_balance" -> AddBalanceScreen(
                        user = user,
                        addBalanceRequests = addBalanceRequests,
                        isBengali = isBengali
                    )

                    "history" -> HistoryScreen(
                        user = user,
                        transactions = transactions,
                        isBengali = isBengali
                    )

                    "services" -> ServicesScreen(
                        user = user,
                        isBengali = isBengali,
                        initialServiceTab = initialServiceTab
                    )

                    "profile" -> ProfileScreen(
                        user = user,
                        users = users,
                        notices = notices,
                        isBengali = isBengali,
                        onNavigateBack = { currentScreen = "home" },
                        onLogout = {
                            TelecomRepository.logout()
                            currentScreen = "home"
                        },
                        onOpenAdmin = {
                            if (user.role == UserRole.ADMIN) {
                                showAdminPanel = true
                            } else {
                                showAdminPinDialog = true
                            }
                        }
                    )
                }
            }
        }

        // Admin Security PIN Dialog
        if (showAdminPinDialog) {
            AdminPinModal(
                isBengali = isBengali,
                onSuccess = {
                    showAdminPinDialog = false
                    showAdminPanel = true
                },
                onDismiss = { showAdminPinDialog = false }
            )
        }

        // Notices Board Dialog
        if (showNoticesDialog) {
            NoticeBoardDialog(
                notices = notices,
                isBengali = isBengali,
                onDismiss = { showNoticesDialog = false }
            )
        }
    }
}

@Composable
private fun AdminPinModal(
    isBengali: Boolean,
    onSuccess: () -> Unit,
    onDismiss: () -> Unit
) {
    var pin by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = if (isBengali) "এডমিন এক্সেস ভেরিফিকেশন" else "Admin Access Verification",
                fontWeight = FontWeight.Bold,
                color = EmeraldDark
            )
        },
        text = {
            Column {
                Text(
                    text = if (isBengali) "এডমিন প্যানেলে প্রবেশের জন্য মাস্টার পিন কোড দিন (ডিফল্ট: 1234)" else "Enter Master PIN to enter Admin Control Panel (Default: 1234)",
                    fontSize = 12.sp,
                    color = TextSecondary
                )
                Spacer(modifier = Modifier.height(10.dp))
                OutlinedTextField(
                    value = pin,
                    onValueChange = {
                        pin = it
                        error = null
                    },
                    label = { Text("Admin PIN") },
                    visualTransformation = PasswordVisualTransformation(),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("admin_pin_input")
                )
                if (error != null) {
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(text = error!!, color = StatusFailed, fontSize = 11.sp)
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (pin == "1234") {
                        onSuccess()
                    } else {
                        error = if (isBengali) "ভুল এডমিন পিন কোড" else "Incorrect Admin PIN (Use 1234)"
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary)
            ) {
                Text(if (isBengali) "প্রবেশ করুন" else "Access")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text(if (isBengali) "বাতিল" else "Cancel") }
        }
    )
}

@Composable
private fun NoticeBoardDialog(
    notices: List<Notice>,
    isBengali: Boolean,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(imageVector = Icons.Default.Campaign, contentDescription = null, tint = EmeraldPrimary)
                Spacer(modifier = Modifier.width(8.dp))
                Text(text = if (isBengali) "অফিসিয়াল নোটিশ বোর্ড" else "Official Notice Board", fontWeight = FontWeight.Bold, fontSize = 17.sp)
            }
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                notices.forEach { n ->
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = EmeraldContainer,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text(text = n.title, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = EmeraldDark)
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(text = if (isBengali) n.textBn else n.textEn, fontSize = 11.sp, color = TextPrimary)
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = onDismiss,
                colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary)
            ) {
                Text(if (isBengali) "ঠিক আছে" else "OK")
            }
        }
    )
}
