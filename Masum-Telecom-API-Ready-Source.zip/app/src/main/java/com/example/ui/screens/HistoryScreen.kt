package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.OrderStatus
import com.example.data.model.TransactionRecord
import com.example.data.model.TransactionType
import com.example.data.model.User
import com.example.data.model.UserRole
import com.example.ui.components.DigitalReceiptDialog
import com.example.ui.components.StatusBadge
import com.example.ui.theme.BackgroundLight
import com.example.ui.theme.BorderLight
import com.example.ui.theme.EmeraldContainer
import com.example.ui.theme.EmeraldDark
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun HistoryScreen(
    user: User,
    transactions: List<TransactionRecord>,
    isBengali: Boolean,
    modifier: Modifier = Modifier
) {
    var searchQuery by remember { mutableStateOf("") }
    var selectedTypeFilter by remember { mutableStateOf<TransactionType?>(null) }
    var selectedStatusFilter by remember { mutableStateOf<OrderStatus?>(null) }
    var selectedTransactionForReceipt by remember { mutableStateOf<TransactionRecord?>(null) }

    // If user is regular dealer, show their transactions. If admin, show all.
    val baseTransactions = remember(user, transactions) {
        if (user.role == UserRole.ADMIN) {
            transactions
        } else {
            transactions.filter { it.userId == user.id }
        }
    }

    val filteredList = baseTransactions.filter { tx ->
        val matchesQuery = searchQuery.isBlank() ||
                tx.recipientNumber.contains(searchQuery.trim()) ||
                tx.trxId.contains(searchQuery.trim(), ignoreCase = true)

        val matchesType = selectedTypeFilter == null || tx.type == selectedTypeFilter
        val matchesStatus = selectedStatusFilter == null || tx.status == selectedStatusFilter

        matchesQuery && matchesType && matchesStatus
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(BackgroundLight)
    ) {
        // Search & Filters Header
        Surface(
            color = Color.White,
            shadowElevation = 2.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                // Search Input
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text(if (isBengali) "নম্বর বা TrxID দিয়ে খুঁজুন..." else "Search by number or TrxID...") },
                    leadingIcon = { Icon(imageVector = Icons.Default.Search, contentDescription = "Search", tint = TextSecondary) },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { searchQuery = "" }) {
                                Icon(imageVector = Icons.Default.Clear, contentDescription = "Clear")
                            }
                        }
                    },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = EmeraldPrimary,
                        unfocusedBorderColor = BorderLight
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("history_search_input")
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Type Filters
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    item {
                        FilterPillSmall(
                            label = if (isBengali) "সকল ধরন" else "All Types",
                            isSelected = selectedTypeFilter == null,
                            onClick = { selectedTypeFilter = null }
                        )
                    }
                    items(TransactionType.entries) { type ->
                        FilterPillSmall(
                            label = if (isBengali) type.banglaName else type.displayName,
                            isSelected = selectedTypeFilter == type,
                            onClick = { selectedTypeFilter = type }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                // Status Filters
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    item {
                        FilterPillSmall(
                            label = if (isBengali) "সকল স্ট্যাটাস" else "All Status",
                            isSelected = selectedStatusFilter == null,
                            onClick = { selectedStatusFilter = null }
                        )
                    }
                    items(OrderStatus.entries) { status ->
                        FilterPillSmall(
                            label = if (isBengali) status.banglaName else status.displayName,
                            isSelected = selectedStatusFilter == status,
                            accentColor = status.color,
                            onClick = { selectedStatusFilter = status }
                        )
                    }
                }
            }
        }

        // Transactions List
        if (filteredList.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(imageVector = Icons.Default.History, contentDescription = null, tint = TextMuted, modifier = Modifier.size(48.dp))
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = if (isBengali) "কোনো লেনদেনের রেকর্ড পাওয়া যায়নি" else "No matching transactions found",
                        color = TextSecondary,
                        fontSize = 14.sp
                    )
                }
            }
        } else {
            LazyColumn(
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(filteredList) { tx ->
                    HistoryItemCard(
                        tx = tx,
                        isBengali = isBengali,
                        onClick = { selectedTransactionForReceipt = tx }
                    )
                }
            }
        }
    }

    // Receipt Dialog
    selectedTransactionForReceipt?.let { tx ->
        DigitalReceiptDialog(
            transaction = tx,
            isBengali = isBengali,
            onDismiss = { selectedTransactionForReceipt = null }
        )
    }
}

@Composable
private fun FilterPillSmall(
    label: String,
    isSelected: Boolean,
    accentColor: Color = EmeraldPrimary,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(16.dp))
            .background(if (isSelected) accentColor else EmeraldContainer.copy(alpha = 0.5f))
            .clickable { onClick() }
            .padding(horizontal = 10.dp, vertical = 5.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            color = if (isSelected) Color.White else EmeraldDark,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
            fontSize = 11.sp
        )
    }
}

@Composable
private fun HistoryItemCard(
    tx: TransactionRecord,
    isBengali: Boolean,
    onClick: () -> Unit
) {
    val dateStr = remember(tx.timestamp) {
        SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault()).format(Date(tx.timestamp))
    }

    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(BorderLight)),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(EmeraldContainer),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = when (tx.type) {
                                TransactionType.RECHARGE -> Icons.Default.PhoneAndroid
                                TransactionType.DRIVE_PURCHASE -> Icons.Default.Bolt
                                TransactionType.REGULAR_PURCHASE -> Icons.Default.Inventory2
                                TransactionType.ADD_BALANCE -> Icons.Default.AccountBalanceWallet
                                TransactionType.BALANCE_TRANSFER -> Icons.Default.SwapHoriz
                                TransactionType.BILL_PAY -> Icons.Default.Receipt
                                TransactionType.GAME_TOPUP -> Icons.Default.SportsEsports
                            },
                            contentDescription = null,
                            tint = EmeraldDark,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(10.dp))

                    Column {
                        Text(
                            text = if (isBengali) tx.type.banglaName else tx.type.displayName,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = TextPrimary
                        )
                        Text(
                            text = "TrxID: ${tx.trxId}",
                            fontSize = 11.sp,
                            color = TextSecondary
                        )
                    }
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = "৳ ${"%.2f".format(tx.amount)}",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = EmeraldDark
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    StatusBadge(status = tx.status, isBengali = isBengali)
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "${tx.recipientNumber} • ${tx.details}",
                    fontSize = 11.sp,
                    color = TextSecondary,
                    maxLines = 1,
                    modifier = Modifier.weight(1f)
                )

                Text(
                    text = dateStr,
                    fontSize = 10.sp,
                    color = TextMuted
                )
            }
        }
    }
}
