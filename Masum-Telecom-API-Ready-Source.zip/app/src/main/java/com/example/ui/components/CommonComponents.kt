package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.LocalOffer
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.SupportAgent
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.BalanceType
import com.example.data.model.Notice
import com.example.data.model.Operator
import com.example.data.model.OrderStatus
import com.example.data.model.TransactionRecord
import com.example.data.model.User
import com.example.data.model.UserRole
import com.example.ui.theme.AmberAccent
import com.example.ui.theme.BorderLight
import com.example.ui.theme.EmeraldContainer
import com.example.ui.theme.EmeraldDark
import com.example.ui.theme.EmeraldLight
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.EmeraldSoft
import com.example.ui.theme.StatusFailed
import com.example.ui.theme.StatusFailedBg
import com.example.ui.theme.StatusPending
import com.example.ui.theme.StatusPendingBg
import com.example.ui.theme.StatusProcessing
import com.example.ui.theme.StatusProcessingBg
import com.example.ui.theme.StatusSuccess
import com.example.ui.theme.StatusSuccessBg
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun AppHeader(
    title: String,
    user: User?,
    isBengali: Boolean,
    onToggleLanguage: () -> Unit,
    onAdminClick: () -> Unit,
    onProfileClick: () -> Unit,
    onNoticeClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        color = EmeraldDark,
        shadowElevation = 4.dp,
        modifier = modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Brand Logo and Name
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .clickable { onProfileClick() }
                        .testTag("brand_header")
                ) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(
                                Brush.linearGradient(
                                    colors = listOf(EmeraldLight, AmberAccent)
                                )
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Bolt,
                            contentDescription = "Masum Telecom",
                            tint = Color.White,
                            modifier = Modifier.size(24.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(10.dp))

                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "MASUM TELECOM",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            // Demo mode tag
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(AmberAccent.copy(alpha = 0.3f))
                                    .padding(horizontal = 5.dp, vertical = 1.dp)
                            ) {
                                Text(
                                    text = "DEMO",
                                    color = AmberAccent,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        if (user != null) {
                            Text(
                                text = "${user.name} • ${if (isBengali) user.role.banglaName else user.role.displayName}",
                                color = EmeraldSoft,
                                fontSize = 11.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }

                // Action buttons
                Row(verticalAlignment = Alignment.CenterVertically) {
                    // Admin Switch Button
                    IconButton(
                        onClick = onAdminClick,
                        modifier = Modifier
                            .size(34.dp)
                            .clip(CircleShape)
                            .background(Color.White.copy(alpha = 0.15f))
                            .testTag("admin_switch_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.AdminPanelSettings,
                            contentDescription = "Admin Panel",
                            tint = if (user?.role == UserRole.ADMIN) AmberAccent else Color.White,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(6.dp))

                    // Language toggle pill
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color.White.copy(alpha = 0.18f))
                            .clickable { onToggleLanguage() }
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                            .testTag("lang_toggle"),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = if (isBengali) "বাং" else "EN",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp
                        )
                    }

                    Spacer(modifier = Modifier.width(6.dp))

                    // Notice button
                    IconButton(
                        onClick = onNoticeClick,
                        modifier = Modifier
                            .size(34.dp)
                            .clip(CircleShape)
                            .background(Color.White.copy(alpha = 0.15f))
                            .testTag("notice_bell")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Notifications,
                            contentDescription = "Notices",
                            tint = Color.White,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun InteractiveWalletCard(
    user: User,
    isBengali: Boolean,
    onAddBalanceClick: () -> Unit,
    onTransferClick: () -> Unit,
    onDrivePackClick: () -> Unit,
    onRegularPackClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    var isBalanceVisible by remember { mutableStateOf(false) }
    var selectedWallet by remember { mutableStateOf(BalanceType.MAIN) }

    // Auto-hide balance after 3.5 seconds like bKash
    LaunchedEffect(isBalanceVisible) {
        if (isBalanceVisible) {
            delay(3500)
            isBalanceVisible = false
        }
    }

    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = EmeraldPrimary),
        elevation = CardDefaults.cardElevation(defaultElevation = 6.dp),
        modifier = modifier
            .fillMaxWidth()
            .testTag("wallet_card")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(EmeraldPrimary, EmeraldDark)
                    )
                )
                .padding(16.dp)
        ) {
            // Tap to Reveal Balance Pill
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Wallet Type Selector Chips
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .background(Color.Black.copy(alpha = 0.2f))
                        .padding(3.dp)
                ) {
                    BalanceType.entries.forEach { bType ->
                        val isSelected = selectedWallet == bType
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(16.dp))
                                .background(if (isSelected) Color.White else Color.Transparent)
                                .clickable { selectedWallet = bType }
                                .padding(horizontal = 10.dp, vertical = 4.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = if (isBengali) {
                                    when (bType) {
                                        BalanceType.MAIN -> "মেইন"
                                        BalanceType.DRIVE -> "ড্রাইভ"
                                        BalanceType.BANK -> "ব্যাংক"
                                    }
                                } else {
                                    when (bType) {
                                        BalanceType.MAIN -> "Main"
                                        BalanceType.DRIVE -> "Drive"
                                        BalanceType.BANK -> "Bank"
                                    }
                                },
                                color = if (isSelected) EmeraldDark else Color.White.copy(alpha = 0.85f),
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                fontSize = 11.sp
                            )
                        }
                    }
                }

                // Balance Tap Capsule Button
                Surface(
                    shape = RoundedCornerShape(24.dp),
                    color = Color.White,
                    shadowElevation = 2.dp,
                    modifier = Modifier
                        .clickable { isBalanceVisible = !isBalanceVisible }
                        .testTag("tap_balance_button")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = if (isBalanceVisible) Icons.Default.Visibility else Icons.Default.AccountBalanceWallet,
                            contentDescription = "Wallet Balance",
                            tint = EmeraldPrimary,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        AnimatedVisibility(
                            visible = isBalanceVisible,
                            enter = fadeIn(),
                            exit = fadeOut()
                        ) {
                            val amount = when (selectedWallet) {
                                BalanceType.MAIN -> user.balanceMain
                                BalanceType.DRIVE -> user.balanceDrive
                                BalanceType.BANK -> user.balanceBank
                            }
                            Text(
                                text = "৳ ${"%.2f".format(amount)}",
                                color = EmeraldDark,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                        }
                        if (!isBalanceVisible) {
                            Text(
                                text = if (isBengali) "ব্যালেন্স দেখুন" else "Tap for Balance",
                                color = EmeraldPrimary,
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 11.sp
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            // Quick Action Buttons Row (Add Balance, Transfer, Drive, Regular)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceAround
            ) {
                QuickWalletActionItem(
                    icon = Icons.Default.AccountBalanceWallet,
                    label = if (isBengali) "অ্যাড ব্যালেন্স" else "Add Balance",
                    onClick = onAddBalanceClick,
                    accentColor = AmberAccent
                )
                QuickWalletActionItem(
                    icon = Icons.Default.SwapHoriz,
                    label = if (isBengali) "ট্রান্সফার" else "Transfer",
                    onClick = onTransferClick
                )
                QuickWalletActionItem(
                    icon = Icons.Default.Bolt,
                    label = if (isBengali) "ড্রাইভ প্যাক" else "Drive Pack",
                    onClick = onDrivePackClick
                )
                QuickWalletActionItem(
                    icon = Icons.Default.Inventory2,
                    label = if (isBengali) "রেগুলার প্যাক" else "Regular",
                    onClick = onRegularPackClick
                )
            }
        }
    }
}

@Composable
private fun QuickWalletActionItem(
    icon: ImageVector,
    label: String,
    onClick: () -> Unit,
    accentColor: Color = Color.White
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clickable { onClick() }
            .padding(4.dp)
    ) {
        Box(
            modifier = Modifier
                .size(42.dp)
                .clip(CircleShape)
                .background(Color.White.copy(alpha = 0.2f))
                .border(1.dp, Color.White.copy(alpha = 0.3f), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = accentColor,
                modifier = Modifier.size(20.dp)
            )
        }
        Spacer(modifier = Modifier.height(5.dp))
        Text(
            text = label,
            color = Color.White,
            fontSize = 11.sp,
            fontWeight = FontWeight.Medium,
            textAlign = TextAlign.Center
        )
    }
}

@Composable
fun NoticeMarqueeCard(
    notices: List<Notice>,
    isBengali: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val activeNotice = notices.firstOrNull { it.isActive } ?: return
    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = EmeraldContainer),
        border = CardDefaults.outlinedCardBorder().copy(brush = Brush.horizontalGradient(listOf(EmeraldLight.copy(alpha = 0.5f), AmberAccent.copy(alpha = 0.5f)))),
        modifier = modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .testTag("notice_marquee_card")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(28.dp)
                    .clip(CircleShape)
                    .background(EmeraldPrimary),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Campaign,
                    contentDescription = "Notice",
                    tint = Color.White,
                    modifier = Modifier.size(16.dp)
                )
            }
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = if (isBengali) activeNotice.textBn else activeNotice.textEn,
                color = EmeraldDark,
                fontSize = 12.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                fontWeight = FontWeight.Medium,
                modifier = Modifier.weight(1f)
            )
        }
    }
}

@Composable
fun StatusBadge(status: OrderStatus, isBengali: Boolean, modifier: Modifier = Modifier) {
    val (bg, fg) = when (status) {
        OrderStatus.PENDING -> StatusPendingBg to StatusPending
        OrderStatus.PROCESSING -> StatusProcessingBg to StatusProcessing
        OrderStatus.SUCCESSFUL -> StatusSuccessBg to StatusSuccess
        OrderStatus.FAILED, OrderStatus.REFUNDED -> StatusFailedBg to StatusFailed
    }
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(6.dp))
            .background(bg)
            .padding(horizontal = 8.dp, vertical = 3.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = if (isBengali) status.banglaName else status.displayName,
            color = fg,
            fontWeight = FontWeight.Bold,
            fontSize = 10.sp
        )
    }
}

@Composable
fun OperatorLogoPill(operator: Operator, isBengali: Boolean, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(operator.color)
            .padding(horizontal = 8.dp, vertical = 3.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = if (isBengali) operator.banglaName else operator.displayName,
            color = Color.White,
            fontWeight = FontWeight.Bold,
            fontSize = 11.sp
        )
    }
}

@Composable
fun DigitalReceiptDialog(
    transaction: TransactionRecord,
    isBengali: Boolean,
    onDismiss: () -> Unit
) {
    val dateStr = remember(transaction.timestamp) {
        SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault()).format(Date(transaction.timestamp))
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (isBengali) "লেনদেন রসিদ" else "Transaction Receipt",
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp,
                    color = EmeraldDark
                )
                StatusBadge(status = transaction.status, isBengali = isBengali)
            }
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(EmeraldContainer)
                        .padding(14.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = if (isBengali) transaction.type.banglaName else transaction.type.displayName,
                            color = EmeraldDark,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "৳ ${"%.2f".format(transaction.amount)}",
                            color = EmeraldDark,
                            fontSize = 24.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                ReceiptRow(label = if (isBengali) "ট্রানজেকশন আইডি" else "TrxID", value = transaction.trxId)
                ReceiptRow(label = if (isBengali) "প্রাপক / একাউন্ট" else "Recipient", value = transaction.recipientNumber)
                if (transaction.operator != null) {
                    ReceiptRow(label = if (isBengali) "অপারেটর" else "Operator", value = if (isBengali) transaction.operator.banglaName else transaction.operator.displayName)
                }
                ReceiptRow(label = if (isBengali) "বিবরণ" else "Details", value = transaction.details)
                ReceiptRow(label = if (isBengali) "তারিখ ও সময়" else "Date & Time", value = dateStr)
                if (transaction.commissionEarned > 0) {
                    ReceiptRow(label = if (isBengali) "অর্জিত কমিশন" else "Commission", value = "৳ ${"%.2f".format(transaction.commissionEarned)}", isHighlight = true)
                }
                if (transaction.failureReason != null) {
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = transaction.failureReason,
                        color = StatusFailed,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = onDismiss,
                colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary)
            ) {
                Text(if (isBengali) "বন্ধ করুন" else "Close")
            }
        }
    )
}

@Composable
private fun ReceiptRow(label: String, value: String, isHighlight: Boolean = false) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, color = TextSecondary, fontSize = 12.sp)
        Text(
            text = value,
            color = if (isHighlight) EmeraldPrimary else TextPrimary,
            fontSize = 12.sp,
            fontWeight = if (isHighlight) FontWeight.Bold else FontWeight.SemiBold
        )
    }
}

@Composable
fun PinConfirmDialog(
    title: String,
    subtitle: String,
    amount: Double,
    isBengali: Boolean,
    onConfirm: (String) -> Unit,
    onDismiss: () -> Unit
) {
    var pin by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = title,
                fontWeight = FontWeight.Bold,
                color = EmeraldDark,
                fontSize = 18.sp
            )
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(text = subtitle, color = TextSecondary, fontSize = 13.sp)
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "৳ ${"%.2f".format(amount)}",
                    color = EmeraldDark,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(14.dp))
                OutlinedTextField(
                    value = pin,
                    onValueChange = {
                        if (it.length <= 6 && it.all { ch -> ch.isDigit() }) {
                            pin = it
                            error = null
                        }
                    },
                    label = { Text(if (isBengali) "আপনার ৪ ডিজিট পিন" else "Enter 4-Digit PIN") },
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                    singleLine = true,
                    isError = error != null,
                    supportingText = {
                        if (error != null) {
                            Text(text = error!!, color = StatusFailed)
                        } else {
                            Text(text = if (isBengali) "নিরাপত্তার জন্য পিন কোড প্রয়োজন (ডিফল্ট: 1234)" else "Default demo PIN: 1234")
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("pin_input_field")
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (pin.length < 4) {
                        error = if (isBengali) "৪ ডিজিটের সঠিক পিন লিখুন" else "Enter 4-digit PIN"
                    } else {
                        onConfirm(pin)
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                modifier = Modifier.testTag("confirm_pin_button")
            ) {
                Text(if (isBengali) "নিশ্চিত করুন" else "Confirm")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(if (isBengali) "বাতিল" else "Cancel", color = TextSecondary)
            }
        }
    )
}

@Composable
fun AppBottomNavBar(
    selectedTab: String,
    onTabSelected: (String) -> Unit,
    isBengali: Boolean,
    modifier: Modifier = Modifier
) {
    NavigationBar(
        containerColor = Color.White,
        tonalElevation = 8.dp,
        modifier = modifier.navigationBarsPadding()
    ) {
        val items = listOf(
            Triple("home", if (isBengali) "হোম" else "Home", Icons.Default.Home),
            Triple("recharge", if (isBengali) "রিচার্জ" else "Recharge", Icons.Default.PhoneAndroid),
            Triple("packages", if (isBengali) "প্যাকেজ" else "Packages", Icons.Default.LocalOffer),
            Triple("history", if (isBengali) "হিস্ট্রি" else "History", Icons.Default.History),
            Triple("services", if (isBengali) "সার্ভিসেস" else "Services", Icons.Default.Receipt)
        )

        items.forEach { (route, label, icon) ->
            val isSelected = selectedTab == route
            NavigationBarItem(
                selected = isSelected,
                onClick = { onTabSelected(route) },
                icon = {
                    Icon(
                        imageVector = icon,
                        contentDescription = label,
                        modifier = Modifier.size(22.dp)
                    )
                },
                label = {
                    Text(
                        text = label,
                        fontSize = 11.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                    )
                },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = EmeraldDark,
                    selectedTextColor = EmeraldDark,
                    indicatorColor = EmeraldSoft,
                    unselectedIconColor = TextMuted,
                    unselectedTextColor = TextMuted
                ),
                modifier = Modifier.testTag("nav_item_$route")
            )
        }
    }
}
