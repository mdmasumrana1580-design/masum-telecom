package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ContactPhone
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Operator
import com.example.data.model.TransactionRecord
import com.example.data.model.User
import com.example.data.repository.TelecomRepository
import com.example.ui.components.DigitalReceiptDialog
import com.example.ui.components.PinConfirmDialog
import com.example.ui.theme.AmberAccent
import com.example.ui.theme.BackgroundLight
import com.example.ui.theme.BorderLight
import com.example.ui.theme.EmeraldContainer
import com.example.ui.theme.EmeraldDark
import com.example.ui.theme.EmeraldLight
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.EmeraldSoft
import com.example.ui.theme.StatusFailed
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlinx.coroutines.launch

@Composable
fun RechargeScreen(
    user: User,
    isBengali: Boolean,
    initialOperator: Operator? = null,
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    var phoneNumber by remember { mutableStateOf("") }
    var selectedOperator by remember { mutableStateOf(initialOperator ?: Operator.GRAMEENPHONE) }
    var connectionType by remember { mutableStateOf("Prepaid") }
    var amountText by remember { mutableStateOf("50") }
    var showPinDialog by remember { mutableStateOf(false) }
    var completedTransaction by remember { mutableStateOf<TransactionRecord?>(null) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    val quickAmounts = listOf("20", "50", "100", "200", "500", "1000")
    val connectionTypes = listOf(
        "Prepaid" to if (isBengali) "প্রিপেইড" else "Prepaid",
        "Postpaid" to if (isBengali) "পোস্টপেইড" else "Postpaid",
        "Skitto" to if (isBengali) "স্কিটো" else "Skitto"
    )

    // Auto-detect operator whenever phone number changes
    fun onPhoneChanged(newVal: String) {
        val filtered = newVal.filter { it.isDigit() }
        if (filtered.length <= 11) {
            phoneNumber = filtered
            errorMessage = null
            val detected = Operator.detectFromNumber(filtered)
            if (detected != null) {
                selectedOperator = detected
            }
        }
    }

    val amount = amountText.toDoubleOrNull() ?: 0.0
    val commissionRate = user.role.commissionRate
    val estimatedCommission = (amount * commissionRate) / 100.0

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(BackgroundLight),
        contentPadding = PaddingValues(16.dp)
    ) {
        item {
            // Header card
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = EmeraldDark),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = if (isBengali) "মোবাইল রিচার্জ (ফ্লেক্সিলোড)" else "Mobile Recharge (Flexiload)",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 17.sp
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = if (isBengali) "কমিশন রেট: $commissionRate% (রোল: ${user.role.banglaName})"
                            else "Commission: $commissionRate% (Role: ${user.role.displayName})",
                            color = EmeraldSoft,
                            fontSize = 12.sp
                        )
                    }

                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = if (isBengali) "মেইন ব্যালেন্স" else "Main Wallet",
                            color = EmeraldSoft,
                            fontSize = 11.sp
                        )
                        Text(
                            text = "৳ ${"%.2f".format(user.balanceMain)}",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
        }

        // Phone number input
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(BorderLight)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = if (isBengali) "গ্রাহকের মোবাইল নম্বর" else "Recipient Mobile Number",
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary,
                        fontSize = 14.sp
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = phoneNumber,
                        onValueChange = { onPhoneChanged(it) },
                        placeholder = { Text("017XXXXXXXX") },
                        leadingIcon = {
                            Icon(
                                imageVector = Icons.Default.PhoneAndroid,
                                contentDescription = "Phone",
                                tint = EmeraldPrimary
                            )
                        },
                        trailingIcon = {
                            // Show detected operator pill
                            Box(
                                modifier = Modifier
                                    .padding(end = 8.dp)
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(selectedOperator.color)
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = if (isBengali) selectedOperator.banglaName else selectedOperator.displayName,
                                    color = Color.White,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = EmeraldPrimary,
                            unfocusedBorderColor = BorderLight
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("recharge_phone_input")
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    // Operator override selectors
                    Text(
                        text = if (isBengali) "অপারেটর নির্বাচন করুন" else "Select Operator",
                        fontWeight = FontWeight.SemiBold,
                        color = TextSecondary,
                        fontSize = 12.sp
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Operator.entries.forEach { op ->
                            val isSelected = op == selectedOperator
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (isSelected) op.color else Color.Transparent)
                                    .border(1.dp, if (isSelected) op.color else BorderLight, RoundedCornerShape(8.dp))
                                    .clickable { selectedOperator = op }
                                    .padding(vertical = 8.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = if (isBengali) op.banglaName else op.displayName,
                                    color = if (isSelected) Color.White else TextPrimary,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                    fontSize = 10.sp,
                                    maxLines = 1
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Connection type
                    Text(
                        text = if (isBengali) "সংযোগের ধরন" else "Connection Type",
                        fontWeight = FontWeight.SemiBold,
                        color = TextSecondary,
                        fontSize = 12.sp
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        connectionTypes.forEach { (typeKey, label) ->
                            val isSelected = connectionType == typeKey
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (isSelected) EmeraldContainer else Color.Transparent)
                                    .border(1.dp, if (isSelected) EmeraldPrimary else BorderLight, RoundedCornerShape(8.dp))
                                    .clickable { connectionType = typeKey }
                                    .padding(vertical = 8.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = label,
                                    color = if (isSelected) EmeraldDark else TextSecondary,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                    fontSize = 11.sp
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
        }

        // Amount Input and Quick Chips
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(BorderLight)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = if (isBengali) "টাকার পরিমাণ" else "Recharge Amount (BDT)",
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary,
                        fontSize = 14.sp
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = amountText,
                        onValueChange = {
                            if (it.length <= 5 && it.all { ch -> ch.isDigit() }) {
                                amountText = it
                                errorMessage = null
                            }
                        },
                        placeholder = { Text("0.00") },
                        prefix = {
                            Text(
                                text = "৳ ",
                                fontWeight = FontWeight.Bold,
                                color = EmeraldDark,
                                fontSize = 18.sp
                            )
                        },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = EmeraldPrimary,
                            unfocusedBorderColor = BorderLight
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("recharge_amount_input")
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // Quick Amounts Grid
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        quickAmounts.forEach { qAmt ->
                            val isSelected = amountText == qAmt
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (isSelected) EmeraldPrimary else EmeraldContainer)
                                    .clickable { amountText = qAmt }
                                    .padding(vertical = 7.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "৳$qAmt",
                                    color = if (isSelected) Color.White else EmeraldDark,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Commission Summary Card
                    if (amount > 0) {
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = EmeraldContainer,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(
                                        text = if (isBengali) "অর্জিত কমিশন ($commissionRate%):" else "Commission Earned ($commissionRate%):",
                                        color = EmeraldDark,
                                        fontSize = 12.sp
                                    )
                                    Text(
                                        text = if (isBengali) "নেট খরচ হবে:" else "Net Wallet Deduction:",
                                        color = TextSecondary,
                                        fontSize = 11.sp
                                    )
                                }

                                Column(horizontalAlignment = Alignment.End) {
                                    Text(
                                        text = "+ ৳ ${"%.2f".format(estimatedCommission)}",
                                        color = EmeraldPrimary,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp
                                    )
                                    Text(
                                        text = "৳ ${"%.2f".format(amount - estimatedCommission)}",
                                        color = TextPrimary,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp
                                    )
                                }
                            }
                        }
                    }

                    if (errorMessage != null) {
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = errorMessage!!,
                            color = StatusFailed,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }

                    Spacer(modifier = Modifier.height(18.dp))

                    Button(
                        onClick = {
                            if (phoneNumber.length != 11 || !phoneNumber.startsWith("01")) {
                                errorMessage = if (isBengali) "সঠিক ১১ ডিজিটের ফোন নম্বর দিন" else "Please enter valid 11-digit phone number"
                            } else if (amount < 10) {
                                errorMessage = if (isBengali) "সর্বনিম্ন রিচার্জ ১০ টাকা" else "Minimum recharge is ৳10"
                            } else if (user.balanceMain < amount) {
                                errorMessage = if (isBengali) "পর্যাপ্ত মেইন ব্যালেন্স নেই" else "Insufficient main balance"
                            } else {
                                errorMessage = null
                                showPinDialog = true
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .testTag("submit_recharge_button")
                    ) {
                        Icon(imageVector = Icons.Default.Send, contentDescription = "Send", modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (isBengali) "রিচার্জ নিশ্চিত করতে এগিয়ে যান" else "Proceed to Recharge",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                    }
                }
            }
        }
    }

    // PIN Confirmation Dialog
    if (showPinDialog) {
        PinConfirmDialog(
            title = if (isBengali) "রিচার্জ নিশ্চিত করুন" else "Confirm Flexiload",
            subtitle = "${selectedOperator.displayName} ($connectionType) to $phoneNumber",
            amount = amount,
            isBengali = isBengali,
            onConfirm = { pin ->
                showPinDialog = false
                val result = TelecomRepository.executeRecharge(
                    recipientNumber = phoneNumber,
                    amount = amount,
                    operator = selectedOperator,
                    connectionType = connectionType,
                    pin = pin
                )
                result.onSuccess { tx ->
                    completedTransaction = tx
                    phoneNumber = ""
                }.onFailure { err ->
                    errorMessage = err.message ?: "Transaction failed"
                }
            },
            onDismiss = { showPinDialog = false }
        )
    }

    // Digital Receipt Dialog on Completion
    completedTransaction?.let { tx ->
        DigitalReceiptDialog(
            transaction = tx,
            isBengali = isBengali,
            onDismiss = { completedTransaction = null }
        )
    }
}
