package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AddBalanceRequest
import com.example.data.model.AdminLedgerStats
import com.example.data.model.Notice
import com.example.data.model.Operator
import com.example.data.model.OrderStatus
import com.example.data.model.PackageCategory
import com.example.data.model.PackageType
import com.example.data.model.TelecomApiConfig
import com.example.data.model.TelecomPackage
import com.example.data.model.TransactionRecord
import com.example.data.model.User
import com.example.data.repository.TelecomRepository
import com.example.ui.components.OperatorLogoPill
import com.example.ui.components.StatusBadge
import com.example.ui.theme.AmberAccent
import com.example.ui.theme.AmberLight
import com.example.ui.theme.BackgroundLight
import com.example.ui.theme.BorderLight
import com.example.ui.theme.EmeraldContainer
import com.example.ui.theme.EmeraldDark
import com.example.ui.theme.EmeraldLight
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.EmeraldSoft
import com.example.ui.theme.StatusFailed
import com.example.ui.theme.StatusProcessing
import com.example.ui.theme.StatusSuccess
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import java.util.UUID

@Composable
fun AdminScreen(
    adminUser: User,
    users: List<User>,
    packages: List<TelecomPackage>,
    transactions: List<TransactionRecord>,
    addBalanceRequests: List<AddBalanceRequest>,
    notices: List<Notice>,
    apiConfig: TelecomApiConfig,
    isBengali: Boolean,
    onExitAdmin: () -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedTab by remember { mutableStateOf(0) }
    var showAddPackageDialog by remember { mutableStateOf(false) }
    var showNoticeEditDialog by remember { mutableStateOf(false) }

    val adminStats = remember(users, transactions, addBalanceRequests) {
        TelecomRepository.getAdminStats()
    }

    val tabs = listOf(
        "Orders" to "অর্ডার ব্যবস্থাপনা",
        "Add Balance" to "ব্যালেন্স অনুমোদন",
        "Packages" to "প্যাকেজ কন্ট্রোল",
        "Dealers" to "ডিলার তালিকা",
        "Gateway & Notice" to "গেটওয়ে ও নোটিশ"
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(BackgroundLight)
    ) {
        // Admin Top Bar
        Surface(color = Color(0xFF1E293B), shadowElevation = 4.dp, modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onExitAdmin) {
                        Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "ADMIN CONTROL PANEL",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(AmberAccent)
                                    .padding(horizontal = 5.dp, vertical = 1.dp)
                            ) {
                                Text(text = "SECURE", color = Color.Black, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                        Text(
                            text = "Auditable Dealer Ledger & Provider Control",
                            color = Color(0xFF94A3B8),
                            fontSize = 11.sp
                        )
                    }
                }

                Button(
                    onClick = onExitAdmin,
                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)
                ) {
                    Text(text = if (isBengali) "ডিলার ভিউ" else "Dealer View", fontSize = 11.sp)
                }
            }
        }

        // Stats Bar
        Surface(color = Color.White, shadowElevation = 1.dp, modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp),
                horizontalArrangement = Arrangement.SpaceAround
            ) {
                AdminStatItem(
                    label = if (isBengali) "মোট ব্যালেন্স" else "Total Balance",
                    value = "৳${"%.0f".format(adminStats.totalSystemBalance)}",
                    color = EmeraldDark
                )
                AdminStatItem(
                    label = if (isBengali) "আজকের বিক্রয়" else "Today Sales",
                    value = "৳${"%.0f".format(adminStats.todaySalesVolume)}",
                    color = Color(0xFF0284C7)
                )
                AdminStatItem(
                    label = if (isBengali) "পেন্ডিং অর্ডার" else "Pending Orders",
                    value = "${adminStats.pendingOrdersCount}",
                    color = AmberAccent
                )
                AdminStatItem(
                    label = if (isBengali) "ব্যালেন্স জমা" else "Pending Add",
                    value = "${adminStats.pendingAddBalanceCount}",
                    color = if (adminStats.pendingAddBalanceCount > 0) Color(0xFFEF4444) else EmeraldPrimary
                )
            }
        }

        // Admin Tabs
        ScrollableTabRow(
            selectedTabIndex = selectedTab,
            containerColor = Color.White,
            contentColor = EmeraldDark,
            edgePadding = 12.dp,
            indicator = { tabPositions ->
                TabRowDefaults.SecondaryIndicator(
                    modifier = Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                    color = EmeraldPrimary,
                    height = 3.dp
                )
            }
        ) {
            tabs.forEachIndexed { index, (en, bn) ->
                val isSelected = selectedTab == index
                Tab(
                    selected = isSelected,
                    onClick = { selectedTab = index },
                    text = {
                        Text(
                            text = if (isBengali) bn else en,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                            fontSize = 12.sp
                        )
                    }
                )
            }
        }

        // Tab Content
        when (selectedTab) {
            0 -> AdminOrdersTab(transactions = transactions, isBengali = isBengali)
            1 -> AdminAddBalanceTab(requests = addBalanceRequests, isBengali = isBengali)
            2 -> AdminPackagesTab(
                packages = packages,
                isBengali = isBengali,
                onAddNewPackage = { showAddPackageDialog = true }
            )
            3 -> AdminDealersTab(users = users, isBengali = isBengali)
            4 -> AdminGatewayNoticeTab(
                apiConfig = apiConfig,
                notices = notices,
                isBengali = isBengali,
                onEditNotice = { showNoticeEditDialog = true }
            )
        }
    }

    // Add Package Dialog
    if (showAddPackageDialog) {
        AdminAddPackageDialog(
            isBengali = isBengali,
            onDismiss = { showAddPackageDialog = false },
            onAdd = { pkg ->
                TelecomRepository.adminAddPackage(pkg)
                showAddPackageDialog = false
            }
        )
    }

    // Edit Notice Dialog
    if (showNoticeEditDialog) {
        AdminNoticeDialog(
            currentNotice = notices.firstOrNull(),
            isBengali = isBengali,
            onDismiss = { showNoticeEditDialog = false },
            onSave = { title, en, bn ->
                TelecomRepository.adminUpdateNotice(title, en, bn)
                showNoticeEditDialog = false
            }
        )
    }
}

@Composable
private fun AdminStatItem(label: String, value: String, color: Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(text = value, fontWeight = FontWeight.Bold, fontSize = 15.sp, color = color)
        Text(text = label, fontSize = 10.sp, color = TextSecondary)
    }
}

// 1. ORDERS MANAGEMENT TAB
@Composable
private fun AdminOrdersTab(transactions: List<TransactionRecord>, isBengali: Boolean) {
    if (transactions.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text(text = if (isBengali) "কোনো অর্ডার নেই" else "No orders in queue", color = TextSecondary)
        }
    } else {
        LazyColumn(contentPadding = PaddingValues(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(transactions) { tx ->
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(BorderLight))
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(text = tx.recipientNumber, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                    Spacer(modifier = Modifier.width(6.dp))
                                    if (tx.operator != null) {
                                        OperatorLogoPill(operator = tx.operator, isBengali = isBengali)
                                    }
                                }
                                Text(
                                    text = "Dealer: ${tx.userName} (${tx.userPhone}) • Role: ${tx.userRole.displayName}",
                                    fontSize = 11.sp,
                                    color = TextSecondary
                                )
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text(text = "৳ ${"%.2f".format(tx.amount)}", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = EmeraldDark)
                                StatusBadge(status = tx.status, isBengali = isBengali)
                            }
                        }

                        Spacer(modifier = Modifier.height(6.dp))
                        Text(text = "TrxID: ${tx.trxId} • ${tx.details}", fontSize = 11.sp, color = TextPrimary)

                        if (tx.failureReason != null) {
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(text = "Reason: ${tx.failureReason}", color = StatusFailed, fontSize = 11.sp)
                        }

                        Spacer(modifier = Modifier.height(10.dp))
                        HorizontalDivider(color = BorderLight)
                        Spacer(modifier = Modifier.height(8.dp))

                        // Action Buttons: Success, Processing, Fail & Refund
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = { TelecomRepository.adminUpdateOrderStatus(tx.id, OrderStatus.SUCCESSFUL) },
                                colors = ButtonDefaults.buttonColors(containerColor = StatusSuccess),
                                shape = RoundedCornerShape(6.dp),
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text(text = if (isBengali) "সফল (Success)" else "Success", fontSize = 11.sp)
                            }

                            Button(
                                onClick = { TelecomRepository.adminUpdateOrderStatus(tx.id, OrderStatus.PROCESSING) },
                                colors = ButtonDefaults.buttonColors(containerColor = StatusProcessing),
                                shape = RoundedCornerShape(6.dp),
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text(text = if (isBengali) "প্রসেসিং" else "Processing", fontSize = 11.sp)
                            }

                            OutlinedButton(
                                onClick = { TelecomRepository.adminUpdateOrderStatus(tx.id, OrderStatus.FAILED) },
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = StatusFailed),
                                shape = RoundedCornerShape(6.dp),
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text(text = if (isBengali) "বাতিল ও রিফান্ড" else "Fail & Refund", fontSize = 11.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}

// 2. ADD BALANCE APPROVAL TAB
@Composable
private fun AdminAddBalanceTab(requests: List<AddBalanceRequest>, isBengali: Boolean) {
    if (requests.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text(text = if (isBengali) "কোনো ব্যালেন্স রিকুয়েস্ট নেই" else "No add-balance requests", color = TextSecondary)
        }
    } else {
        LazyColumn(contentPadding = PaddingValues(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(requests) { req ->
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(BorderLight))
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(30.dp)
                                        .clip(CircleShape)
                                        .background(req.method.color),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(text = req.method.displayName.take(1), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                }
                                Spacer(modifier = Modifier.width(8.dp))
                                Column {
                                    Text(text = "${req.method.displayName} • TrxID: ${req.trxId}", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                    Text(text = "Sender: ${req.senderNumber} • User: ${req.userName}", fontSize = 11.sp, color = TextSecondary)
                                }
                            }

                            Column(horizontalAlignment = Alignment.End) {
                                Text(text = "৳ ${"%.2f".format(req.amount)}", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = EmeraldDark)
                                StatusBadge(status = req.status, isBengali = isBengali)
                            }
                        }

                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Target Wallet: ${if (isBengali) req.balanceType.banglaName else req.balanceType.displayName} ${if (req.note.isNotBlank()) "• Note: ${req.note}" else ""}",
                            fontSize = 11.sp,
                            color = TextPrimary
                        )

                        if (req.status == OrderStatus.PENDING) {
                            Spacer(modifier = Modifier.height(12.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Button(
                                    onClick = { TelecomRepository.adminApproveAddBalance(req.id) },
                                    colors = ButtonDefaults.buttonColors(containerColor = StatusSuccess),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Icon(imageVector = Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(text = if (isBengali) "অনুমোদন ও ব্যালেন্স যোগ" else "Approve & Credit", fontSize = 12.sp)
                                }

                                OutlinedButton(
                                    onClick = { TelecomRepository.adminRejectAddBalance(req.id) },
                                    colors = ButtonDefaults.outlinedButtonColors(contentColor = StatusFailed),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.weight(0.7f)
                                ) {
                                    Icon(imageVector = Icons.Default.Close, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(text = if (isBengali) "বাতিল" else "Reject", fontSize = 12.sp)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// 3. PACKAGES TAB
@Composable
private fun AdminPackagesTab(
    packages: List<TelecomPackage>,
    isBengali: Boolean,
    onAddNewPackage: () -> Unit
) {
    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = if (isBengali) "মোট প্যাকেজ সংখ্যা: ${packages.size}" else "Total Packages: ${packages.size}",
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp
            )
            Button(
                onClick = onAddNewPackage,
                colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                shape = RoundedCornerShape(8.dp)
            ) {
                Icon(imageVector = Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text(text = if (isBengali) "নতুন প্যাকেজ যোগ" else "Add Package", fontSize = 12.sp)
            }
        }

        LazyColumn(contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(packages) { pkg ->
                Card(
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(BorderLight))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                OperatorLogoPill(operator = pkg.operator, isBengali = isBengali)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(text = pkg.packageType.displayName, fontSize = 10.sp, color = TextSecondary)
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(text = pkg.title, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Text(text = "Offer: ৳${pkg.offerPrice} • Reg: ৳${pkg.regularPrice} • Commission: ৳${pkg.commission}", fontSize = 11.sp, color = EmeraldDark)
                        }

                        Switch(
                            checked = pkg.isActive,
                            onCheckedChange = { TelecomRepository.adminTogglePackage(pkg.id) },
                            colors = SwitchDefaults.colors(checkedThumbColor = EmeraldPrimary)
                        )
                    }
                }
            }
        }
    }
}

// 4. DEALERS TAB
@Composable
private fun AdminDealersTab(users: List<User>, isBengali: Boolean) {
    LazyColumn(contentPadding = PaddingValues(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        items(users) { user ->
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(BorderLight))
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(text = user.name, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                Spacer(modifier = Modifier.width(6.dp))
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(EmeraldContainer)
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text(text = user.role.displayName, color = EmeraldDark, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                            Text(text = "Phone: ${user.phone} • Email: ${user.email}", fontSize = 11.sp, color = TextSecondary)
                        }

                        Switch(
                            checked = user.isActive,
                            onCheckedChange = { TelecomRepository.adminToggleUserStatus(user.id) },
                            colors = SwitchDefaults.colors(checkedThumbColor = EmeraldPrimary)
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    HorizontalDivider(color = BorderLight)
                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(text = "Main: ৳${"%.2f".format(user.balanceMain)}", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = EmeraldDark)
                        Text(text = "Drive: ৳${"%.2f".format(user.balanceDrive)}", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFFD97706))
                        Text(text = "Bank: ৳${"%.2f".format(user.balanceBank)}", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFF0284C7))
                    }
                }
            }
        }
    }
}

// 5. GATEWAY & NOTICE TAB
@Composable
private fun AdminGatewayNoticeTab(
    apiConfig: TelecomApiConfig,
    notices: List<Notice>,
    isBengali: Boolean,
    onEditNotice: () -> Unit
) {
    var baseUrl by remember { mutableStateOf(apiConfig.baseUrl) }
    var apiKey by remember { mutableStateOf(apiConfig.apiKey) }
    var isDemoMode by remember { mutableStateOf(apiConfig.isDemoMode) }
    var configSaved by remember { mutableStateOf(false) }

    LazyColumn(contentPadding = PaddingValues(14.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        // Notice Editor Card
        item {
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(BorderLight))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = if (isBengali) "ব্রডকাস্ট নোটিশ বোর্ড" else "Broadcast Notice Board", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Button(
                            onClick = onEditNotice,
                            colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                            shape = RoundedCornerShape(6.dp),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp)
                        ) {
                            Text(text = if (isBengali) "এডিট করুন" else "Edit Notice", fontSize = 11.sp)
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))
                    val notice = notices.firstOrNull()
                    if (notice != null) {
                        Text(text = notice.title, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = EmeraldDark)
                        Text(text = notice.textBn, fontSize = 11.sp, color = TextSecondary)
                    }
                }
            }
        }

        // Telecom Gateway API Configuration
        item {
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(BorderLight))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = if (isBengali) "টেলিকম গেটওয়ে ইন্টিগ্রেশন লেয়ার" else "Telecom Provider Gateway Settings",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Authorized aggregator credentials & server endpoint. In demo mode, live credits are simulated safely.",
                        fontSize = 11.sp,
                        color = TextSecondary
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(text = "Gateway Environment Mode", fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                            Text(
                                text = if (isDemoMode) "DEMO MODE (Simulated Safe Execution)" else "LIVE PRODUCTION MODE",
                                color = if (isDemoMode) AmberAccent else StatusSuccess,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp
                            )
                        }
                        Switch(
                            checked = isDemoMode,
                            onCheckedChange = { isDemoMode = it },
                            colors = SwitchDefaults.colors(checkedThumbColor = AmberAccent)
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = baseUrl,
                        onValueChange = { baseUrl = it },
                        label = { Text("Provider Gateway Endpoint URL") },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = EmeraldPrimary, unfocusedBorderColor = BorderLight),
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = apiKey,
                        onValueChange = { apiKey = it },
                        label = { Text("Server API Key") },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = EmeraldPrimary, unfocusedBorderColor = BorderLight),
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Button(
                        onClick = {
                            TelecomRepository.adminUpdateApiConfig(
                                apiConfig.copy(baseUrl = baseUrl, apiKey = apiKey, isDemoMode = isDemoMode)
                            )
                            configSaved = true
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(text = if (isBengali) "কনফিগারেশন সংরক্ষণ করুন" else "Save Gateway Config", fontWeight = FontWeight.Bold)
                    }

                    if (configSaved) {
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(text = "✓ Configuration saved securely", color = StatusSuccess, fontSize = 11.sp)
                    }
                }
            }
        }
    }
}

// Dialog: Add Package
@Composable
private fun AdminAddPackageDialog(
    isBengali: Boolean,
    onDismiss: () -> Unit,
    onAdd: (TelecomPackage) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var operator by remember { mutableStateOf(Operator.GRAMEENPHONE) }
    var dataVolume by remember { mutableStateOf("40 GB") }
    var minutes by remember { mutableStateOf("800 Min") }
    var validity by remember { mutableStateOf("30 Days") }
    var regularPrice by remember { mutableStateOf("799") }
    var offerPrice by remember { mutableStateOf("560") }
    var commission by remember { mutableStateOf("239") }
    var isDrive by remember { mutableStateOf(true) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(text = if (isBengali) "নতুন প্যাকেজ তৈরি করুন" else "Create Telecom Package", fontWeight = FontWeight.Bold) },
        text = {
            LazyColumn(modifier = Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                item {
                    OutlinedTextField(
                        value = title,
                        onValueChange = { title = it },
                        label = { Text("Package Title") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                item {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        Operator.entries.forEach { op ->
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(if (operator == op) op.color else Color.LightGray.copy(alpha = 0.3f))
                                    .clickable { operator = op }
                                    .padding(vertical = 6.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(text = op.displayName.take(3), color = if (operator == op) Color.White else Color.Black, fontSize = 10.sp)
                            }
                        }
                    }
                }
                item {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(value = dataVolume, onValueChange = { dataVolume = it }, label = { Text("Data") }, modifier = Modifier.weight(1f))
                        OutlinedTextField(value = minutes, onValueChange = { minutes = it }, label = { Text("Minutes") }, modifier = Modifier.weight(1f))
                    }
                }
                item {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(value = regularPrice, onValueChange = { regularPrice = it }, label = { Text("Regular ৳") }, modifier = Modifier.weight(1f))
                        OutlinedTextField(value = offerPrice, onValueChange = { offerPrice = it }, label = { Text("Offer ৳") }, modifier = Modifier.weight(1f))
                    }
                }
                item {
                    OutlinedTextField(value = commission, onValueChange = { commission = it }, label = { Text("Cashback / Commission ৳") }, modifier = Modifier.fillMaxWidth())
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val pkg = TelecomPackage(
                        id = "pkg_" + UUID.randomUUID().toString().substring(0, 8),
                        operator = operator,
                        title = title.ifBlank { "${operator.displayName} $dataVolume + $minutes" },
                        titleBn = title.ifBlank { "${operator.banglaName} $dataVolume + $minutes" },
                        dataVolume = dataVolume,
                        minutes = minutes,
                        sms = "0 SMS",
                        validity = validity,
                        validityBn = validity,
                        regularPrice = regularPrice.toDoubleOrNull() ?: 500.0,
                        offerPrice = offerPrice.toDoubleOrNull() ?: 400.0,
                        commission = commission.toDoubleOrNull() ?: 100.0,
                        category = PackageCategory.COMBO,
                        packageType = if (isDrive) PackageType.DRIVE else PackageType.REGULAR
                    )
                    onAdd(pkg)
                },
                colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary)
            ) {
                Text(if (isBengali) "প্যাকেজ সংরক্ষণ" else "Save Package")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text(if (isBengali) "বাতিল" else "Cancel") }
        }
    )
}

// Dialog: Edit Notice
@Composable
private fun AdminNoticeDialog(
    currentNotice: Notice?,
    isBengali: Boolean,
    onDismiss: () -> Unit,
    onSave: (title: String, en: String, bn: String) -> Unit
) {
    var title by remember { mutableStateOf(currentNotice?.title ?: "") }
    var textEn by remember { mutableStateOf(currentNotice?.textEn ?: "") }
    var textBn by remember { mutableStateOf(currentNotice?.textBn ?: "") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(text = if (isBengali) "নোটিশ পরিবর্তন করুন" else "Update Broadcast Notice") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("Notice Title") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = textBn, onValueChange = { textBn = it }, label = { Text("বাংলা নোটিশ") }, maxLines = 3, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = textEn, onValueChange = { textEn = it }, label = { Text("English Notice") }, maxLines = 3, modifier = Modifier.fillMaxWidth())
            }
        },
        confirmButton = {
            Button(
                onClick = { onSave(title, textEn, textBn) },
                colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary)
            ) {
                Text(if (isBengali) "সেভ করুন" else "Save")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text(if (isBengali) "বাতিল" else "Cancel") }
        }
    )
}
