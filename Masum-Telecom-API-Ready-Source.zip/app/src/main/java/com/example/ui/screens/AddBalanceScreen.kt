package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AddBalanceRequest
import com.example.data.model.BalanceType
import com.example.data.model.PaymentMethod
import com.example.data.model.User
import com.example.data.repository.TelecomRepository
import com.example.ui.components.StatusBadge
import com.example.ui.theme.AmberAccent
import com.example.ui.theme.BackgroundLight
import com.example.ui.theme.BorderLight
import com.example.ui.theme.EmeraldContainer
import com.example.ui.theme.EmeraldDark
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.EmeraldSoft
import com.example.ui.theme.StatusFailed
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun AddBalanceScreen(
    user: User,
    addBalanceRequests: List<AddBalanceRequest>,
    isBengali: Boolean,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var selectedMethod by remember { mutableStateOf(PaymentMethod.BKASH) }
    var selectedWallet by remember { mutableStateOf(BalanceType.MAIN) }
    var senderPhone by remember { mutableStateOf(user.phone) }
    var amountText by remember { mutableStateOf("") }
    var trxIdText by remember { mutableStateOf("") }
    var noteText by remember { mutableStateOf("") }
    var submissionSuccess by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    fun copyToClipboard(text: String) {
        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = ClipData.newPlainText("Telecom Number", text)
        clipboard.setPrimaryClip(clip)
        Toast.makeText(context, if (isBengali) "নম্বর কপি করা হয়েছে: $text" else "Copied: $text", Toast.LENGTH_SHORT).show()
    }

    val userRequests = addBalanceRequests.filter { it.userId == user.id }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(BackgroundLight),
        contentPadding = PaddingValues(16.dp)
    ) {
        // Banner Header
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = EmeraldDark),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (isBengali) "অ্যাড ব্যালেন্স (বিকাশ/নগদ/রকেট)" else "Add Wallet Balance",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp
                        )
                        Icon(imageVector = Icons.Default.AccountBalanceWallet, contentDescription = null, tint = AmberAccent)
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = if (isBengali)
                            "নিচের যেকোনো নম্বরে Send Money করার পর প্রাপ্ত TrxID দিয়ে সাবমিট করুন। অ্যাডমিন ভেরিফাই করে ব্যালেন্স যোগ করে দিবে।"
                        else
                            "Send Money to our official number, then enter the TrxID below to request balance top-up.",
                        color = EmeraldSoft,
                        fontSize = 12.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
        }

        // 1. Official Merchant Numbers (One-click copy)
        item {
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(BorderLight)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = if (isBengali) "টাকা পাঠানোর অফিসিয়াল নম্বরসমূহ" else "Official Payment Numbers",
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary,
                        fontSize = 14.sp
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    PaymentMethod.entries.forEach { method ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(BackgroundLight)
                                .clickable {
                                    selectedMethod = method
                                    copyToClipboard(method.number)
                                }
                                .padding(horizontal = 10.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(28.dp)
                                        .clip(CircleShape)
                                        .background(method.color),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = method.displayName.take(1),
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp
                                    )
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(text = if (isBengali) method.banglaName else method.displayName, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = TextPrimary)
                                    Text(text = "${method.number} (Personal/Send Money)", fontSize = 11.sp, color = TextSecondary)
                                }
                            }

                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(text = if (isBengali) "কপি" else "Copy", color = EmeraldPrimary, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                                Spacer(modifier = Modifier.width(4.dp))
                                Icon(imageVector = Icons.Default.ContentCopy, contentDescription = "Copy", tint = EmeraldPrimary, modifier = Modifier.size(14.dp))
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
        }

        // 2. Submission Form
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(BorderLight)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = if (isBengali) "ব্যালেন্স জমার রিকুয়েস্ট ফর্ম" else "Submit Add Balance Request",
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary,
                        fontSize = 15.sp
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // Select Payment Method
                    Text(text = if (isBengali) "পেমেন্ট মাধ্যম" else "Payment Method", fontSize = 12.sp, color = TextSecondary, fontWeight = FontWeight.Medium)
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        PaymentMethod.entries.forEach { method ->
                            val isSelected = selectedMethod == method
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (isSelected) method.color else Color.Transparent)
                                    .border(1.dp, if (isSelected) method.color else BorderLight, RoundedCornerShape(8.dp))
                                    .clickable { selectedMethod = method }
                                    .padding(vertical = 8.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = if (isBengali) method.banglaName else method.displayName,
                                    color = if (isSelected) Color.White else TextPrimary,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                    fontSize = 11.sp
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Select Target Wallet
                    Text(text = if (isBengali) "কোন ওয়ালেটে জমা নিবেন?" else "Target Wallet", fontSize = 12.sp, color = TextSecondary, fontWeight = FontWeight.Medium)
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        BalanceType.entries.forEach { bType ->
                            val isSelected = selectedWallet == bType
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (isSelected) EmeraldContainer else Color.Transparent)
                                    .border(1.dp, if (isSelected) EmeraldPrimary else BorderLight, RoundedCornerShape(8.dp))
                                    .clickable { selectedWallet = bType }
                                    .padding(vertical = 8.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = if (isBengali) {
                                        when (bType) {
                                            BalanceType.MAIN -> "মেইন ওয়ালেট"
                                            BalanceType.DRIVE -> "ড্রাইভ ওয়ালেট"
                                            BalanceType.BANK -> "ব্যাংক ওয়ালেট"
                                        }
                                    } else bType.displayName,
                                    color = if (isSelected) EmeraldDark else TextSecondary,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                    fontSize = 11.sp,
                                    maxLines = 1
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Sender Number
                    OutlinedTextField(
                        value = senderPhone,
                        onValueChange = {
                            if (it.length <= 11 && it.all { ch -> ch.isDigit() }) {
                                senderPhone = it
                                errorMessage = null
                            }
                        },
                        label = { Text(if (isBengali) "যে নম্বর থেকে টাকা পাঠিয়েছেন (Sender)" else "Sender Number") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = EmeraldPrimary,
                            unfocusedBorderColor = BorderLight
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // Amount
                    OutlinedTextField(
                        value = amountText,
                        onValueChange = {
                            if (it.length <= 6 && it.all { ch -> ch.isDigit() }) {
                                amountText = it
                                errorMessage = null
                            }
                        },
                        label = { Text(if (isBengali) "টাকার পরিমাণ (সর্বনিম্ন ২০)" else "Amount in BDT (Min 20)") },
                        prefix = { Text("৳ ", fontWeight = FontWeight.Bold, color = EmeraldDark) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = EmeraldPrimary,
                            unfocusedBorderColor = BorderLight
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("add_balance_amount_input")
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // TrxID
                    OutlinedTextField(
                        value = trxIdText,
                        onValueChange = {
                            if (it.length <= 15) {
                                trxIdText = it.uppercase()
                                errorMessage = null
                            }
                        },
                        label = { Text(if (isBengali) "ট্রানজেকশন আইডি (TrxID)" else "Transaction ID (TrxID)") },
                        placeholder = { Text("e.g. BKH982104") },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = EmeraldPrimary,
                            unfocusedBorderColor = BorderLight
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("add_balance_trxid_input")
                    )

                    if (errorMessage != null) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(text = errorMessage!!, color = StatusFailed, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                    }

                    if (submissionSuccess) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = EmeraldContainer,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(imageVector = Icons.Default.CheckCircle, contentDescription = null, tint = EmeraldPrimary, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = if (isBengali) "অনুরোধ জমা হয়েছে! অ্যাডমিন অনুমোদন করলে ব্যালেন্স যোগ হবে।" else "Request submitted! Balance will be credited upon Admin approval.",
                                    color = EmeraldDark,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Button(
                        onClick = {
                            val amt = amountText.toDoubleOrNull() ?: 0.0
                            val res = TelecomRepository.submitAddBalanceRequest(
                                method = selectedMethod,
                                senderNumber = senderPhone,
                                trxId = trxIdText,
                                amount = amt,
                                balanceType = selectedWallet,
                                note = noteText
                            )
                            res.onSuccess {
                                submissionSuccess = true
                                amountText = ""
                                trxIdText = ""
                                errorMessage = null
                            }.onFailure { err ->
                                submissionSuccess = false
                                errorMessage = err.message
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .testTag("submit_add_balance_btn")
                    ) {
                        Icon(imageVector = Icons.Default.Send, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (isBengali) "ব্যালেন্স রিকুয়েস্ট পাঠান" else "Submit Balance Request",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))
        }

        // 3. User's Recent Add Balance Requests
        item {
            Text(
                text = if (isBengali) "আপনার পূর্ববর্তী ব্যালেন্স রিকুয়েস্ট" else "Your Add Balance Requests",
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp,
                color = TextPrimary
            )
            Spacer(modifier = Modifier.height(10.dp))
        }

        if (userRequests.isEmpty()) {
            item {
                Text(
                    text = if (isBengali) "কোনো ব্যালেন্স রিকুয়েস্ট পাওয়া যায়নি" else "No requests submitted yet",
                    color = TextSecondary,
                    fontSize = 12.sp
                )
            }
        } else {
            items(userRequests) { req ->
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(BorderLight)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(text = req.method.displayName, fontWeight = FontWeight.Bold, color = req.method.color, fontSize = 13.sp)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(text = "TrxID: ${req.trxId}", fontWeight = FontWeight.SemiBold, fontSize = 12.sp, color = TextPrimary)
                            }
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "From: ${req.senderNumber} • ${if (isBengali) req.balanceType.banglaName else req.balanceType.displayName}",
                                fontSize = 11.sp,
                                color = TextSecondary
                            )
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            Text(text = "৳ ${"%.2f".format(req.amount)}", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = EmeraldDark)
                            Spacer(modifier = Modifier.height(4.dp))
                            StatusBadge(status = req.status, isBengali = isBengali)
                        }
                    }
                }
            }
        }
    }
}
