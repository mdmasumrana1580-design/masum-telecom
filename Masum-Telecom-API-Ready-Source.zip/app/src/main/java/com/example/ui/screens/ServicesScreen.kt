package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ElectricBolt
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material.icons.filled.WaterDrop
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.BalanceType
import com.example.data.model.TransactionRecord
import com.example.data.model.TransactionType
import com.example.data.model.User
import com.example.data.repository.TelecomRepository
import com.example.ui.components.DigitalReceiptDialog
import com.example.ui.components.PinConfirmDialog
import com.example.ui.theme.BackgroundLight
import com.example.ui.theme.BorderLight
import com.example.ui.theme.EmeraldContainer
import com.example.ui.theme.EmeraldDark
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.EmeraldSoft
import com.example.ui.theme.StatusFailed
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun ServicesScreen(
    user: User,
    isBengali: Boolean,
    initialServiceTab: String = "bill_pay",
    modifier: Modifier = Modifier
) {
    var selectedTab by remember { mutableStateOf(if (initialServiceTab == "transfer") 0 else if (initialServiceTab == "game_topup") 2 else 1) }

    var recipientAccount by remember { mutableStateOf("") }
    var amountText by remember { mutableStateOf("100") }
    var selectedWallet by remember { mutableStateOf(BalanceType.MAIN) }
    var selectedProvider by remember { mutableStateOf("Palli Bidyut (BREB)") }
    var showPinDialog by remember { mutableStateOf(false) }
    var completedTransaction by remember { mutableStateOf<TransactionRecord?>(null) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    val utilityProviders = listOf(
        "Palli Bidyut (পল্লী বিদ্যুৎ)",
        "DESCO (ডেসকো)",
        "NESCO (নেসকো)",
        "Titas Gas (তিতাস গ্যাস)",
        "Dhaka WASA (ঢাকা ওয়াসা)"
    )

    val gamePackages = listOf(
        "Free Fire: 115 Diamonds (৳85)",
        "Free Fire: 240 Diamonds (৳170)",
        "Free Fire: 610 Diamonds (৳420)",
        "PUBG Mobile: 60 UC (৳95)",
        "PUBG Mobile: 325 UC (৳450)"
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(BackgroundLight)
    ) {
        // Tab Header
        Surface(color = Color.White, shadowElevation = 2.dp, modifier = Modifier.fillMaxWidth()) {
            TabRow(
                selectedTabIndex = selectedTab,
                containerColor = Color.White,
                contentColor = EmeraldPrimary,
                indicator = { tabPositions ->
                    TabRowDefaults.SecondaryIndicator(
                        modifier = Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                        color = EmeraldPrimary,
                        height = 3.dp
                    )
                }
            ) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = {
                        selectedTab = 0
                        errorMessage = null
                    },
                    text = {
                        Text(
                            text = if (isBengali) "ট্রান্সফার" else "Transfer",
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                    }
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = {
                        selectedTab = 1
                        errorMessage = null
                    },
                    text = {
                        Text(
                            text = if (isBengali) "বিল পে" else "Bill Pay",
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                    }
                )
                Tab(
                    selected = selectedTab == 2,
                    onClick = {
                        selectedTab = 2
                        errorMessage = null
                    },
                    text = {
                        Text(
                            text = if (isBengali) "গেম টপ-আপ" else "Game Top-up",
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                    }
                )
            }
        }

        LazyColumn(
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            when (selectedTab) {
                0 -> {
                    // 1. Balance Transfer
                    item {
                        Card(
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = EmeraldDark),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text(
                                    text = if (isBengali) "ব্যালেন্স ট্রান্সফার (ডিলার টু ডিলার)" else "Dealer-to-Dealer Balance Transfer",
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 16.sp
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = if (isBengali) "অন্য যেকোনো নিবন্ধিত ডিলারের নম্বরে তাৎক্ষণিক ব্যালেন্স ট্রান্সফার করুন।" else "Instantly transfer balance to another registered dealer.",
                                    color = EmeraldSoft,
                                    fontSize = 12.sp
                                )
                            }
                        }
                    }

                    item {
                        Card(
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(BorderLight)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text(text = if (isBengali) "কোন ওয়ালেট থেকে পাঠাবেন?" else "Source Wallet", fontSize = 12.sp, color = TextSecondary)
                                Spacer(modifier = Modifier.height(6.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    BalanceType.entries.forEach { bType ->
                                        val isSelected = selectedWallet == bType
                                        val bal = when (bType) {
                                            BalanceType.MAIN -> user.balanceMain
                                            BalanceType.DRIVE -> user.balanceDrive
                                            BalanceType.BANK -> user.balanceBank
                                        }
                                        Box(
                                            modifier = Modifier
                                                .weight(1f)
                                                .clip(RoundedCornerShape(8.dp))
                                                .background(if (isSelected) EmeraldContainer else Color.Transparent)
                                                .border(1.dp, if (isSelected) EmeraldPrimary else BorderLight, RoundedCornerShape(8.dp))
                                                .clickable { selectedWallet = bType }
                                                .padding(vertical = 8.dp),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                                Text(
                                                    text = if (isBengali) bType.banglaName else bType.displayName,
                                                    fontSize = 10.sp,
                                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                                    color = if (isSelected) EmeraldDark else TextPrimary
                                                )
                                                Text(
                                                    text = "৳${"%.0f".format(bal)}",
                                                    fontSize = 11.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = EmeraldPrimary
                                                )
                                            }
                                        }
                                    }
                                }

                                Spacer(modifier = Modifier.height(14.dp))

                                OutlinedTextField(
                                    value = recipientAccount,
                                    onValueChange = {
                                        if (it.length <= 11 && it.all { ch -> ch.isDigit() }) recipientAccount = it
                                    },
                                    label = { Text(if (isBengali) "প্রাপক ডিলারের ফোন নম্বর" else "Receiver Dealer Phone") },
                                    placeholder = { Text("01XXXXXXXXX") },
                                    singleLine = true,
                                    colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = EmeraldPrimary, unfocusedBorderColor = BorderLight),
                                    modifier = Modifier.fillMaxWidth()
                                )

                                Spacer(modifier = Modifier.height(10.dp))

                                OutlinedTextField(
                                    value = amountText,
                                    onValueChange = {
                                        if (it.length <= 6 && it.all { ch -> ch.isDigit() }) amountText = it
                                    },
                                    label = { Text(if (isBengali) "টাকার পরিমাণ (সর্বনিম্ন ৫০)" else "Amount in BDT (Min 50)") },
                                    prefix = { Text("৳ ", fontWeight = FontWeight.Bold) },
                                    singleLine = true,
                                    colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = EmeraldPrimary, unfocusedBorderColor = BorderLight),
                                    modifier = Modifier.fillMaxWidth()
                                )

                                if (errorMessage != null) {
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Text(text = errorMessage!!, color = StatusFailed, fontSize = 12.sp)
                                }

                                Spacer(modifier = Modifier.height(16.dp))

                                Button(
                                    onClick = {
                                        val amt = amountText.toDoubleOrNull() ?: 0.0
                                        if (recipientAccount.length != 11) {
                                            errorMessage = if (isBengali) "সঠিক ১১ ডিজিটের ফোন নম্বর দিন" else "Enter valid 11-digit phone"
                                        } else if (amt < 50) {
                                            errorMessage = if (isBengali) "সর্বনিম্ন ট্রান্সফার ৫০ টাকা" else "Minimum transfer is ৳50"
                                        } else {
                                            errorMessage = null
                                            showPinDialog = true
                                        }
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(50.dp)
                                ) {
                                    Icon(imageVector = Icons.Default.SwapHoriz, contentDescription = null)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(text = if (isBengali) "ব্যালেন্স ট্রান্সফার করুন" else "Transfer Balance", fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
                1 -> {
                    // 2. Bill Payment
                    item {
                        Card(
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(BorderLight)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text(
                                    text = if (isBengali) "ইউটিলিটি বিল পরিশোধ" else "Utility Bill Payment",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp,
                                    color = TextPrimary
                                )
                                Spacer(modifier = Modifier.height(10.dp))

                                // Select Provider
                                utilityProviders.forEach { prov ->
                                    val isSelected = selectedProvider == prov
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(vertical = 4.dp)
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(if (isSelected) EmeraldContainer else BackgroundLight)
                                            .clickable { selectedProvider = prov }
                                            .padding(10.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(
                                            imageVector = if (prov.contains("Gas")) Icons.Default.LocalFireDepartment
                                            else if (prov.contains("WASA")) Icons.Default.WaterDrop
                                            else Icons.Default.ElectricBolt,
                                            contentDescription = null,
                                            tint = if (isSelected) EmeraldDark else TextSecondary,
                                            modifier = Modifier.size(18.dp)
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(
                                            text = prov,
                                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                            color = if (isSelected) EmeraldDark else TextPrimary,
                                            fontSize = 12.sp
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(12.dp))

                                OutlinedTextField(
                                    value = recipientAccount,
                                    onValueChange = { recipientAccount = it },
                                    label = { Text(if (isBengali) "গ্রাহক / মিটার একাউন্ট নম্বর" else "Account / Meter Number") },
                                    singleLine = true,
                                    colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = EmeraldPrimary, unfocusedBorderColor = BorderLight),
                                    modifier = Modifier.fillMaxWidth()
                                )

                                Spacer(modifier = Modifier.height(10.dp))

                                OutlinedTextField(
                                    value = amountText,
                                    onValueChange = { if (it.all { ch -> ch.isDigit() }) amountText = it },
                                    label = { Text(if (isBengali) "বিলের পরিমাণ (টাকা)" else "Bill Amount (BDT)") },
                                    prefix = { Text("৳ ") },
                                    singleLine = true,
                                    colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = EmeraldPrimary, unfocusedBorderColor = BorderLight),
                                    modifier = Modifier.fillMaxWidth()
                                )

                                if (errorMessage != null) {
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Text(text = errorMessage!!, color = StatusFailed, fontSize = 12.sp)
                                }

                                Spacer(modifier = Modifier.height(16.dp))

                                Button(
                                    onClick = {
                                        val amt = amountText.toDoubleOrNull() ?: 0.0
                                        if (recipientAccount.isBlank()) {
                                            errorMessage = if (isBengali) "মিটার বা একাউন্ট নম্বর লিখুন" else "Enter meter/account number"
                                        } else if (amt < 50) {
                                            errorMessage = if (isBengali) "সঠিক পরিমাণ লিখুন" else "Enter valid amount"
                                        } else {
                                            errorMessage = null
                                            showPinDialog = true
                                        }
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(50.dp)
                                ) {
                                    Text(text = if (isBengali) "বিল পরিশোধ করুন" else "Pay Bill", fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
                2 -> {
                    // 3. Game Top-up
                    item {
                        Card(
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(BorderLight)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text(
                                    text = if (isBengali) "ফ্রি ফায়ার ও পাবজি গেম টপ-আপ" else "Game Top-up (Free Fire & PUBG)",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp,
                                    color = TextPrimary
                                )
                                Spacer(modifier = Modifier.height(10.dp))

                                OutlinedTextField(
                                    value = recipientAccount,
                                    onValueChange = { recipientAccount = it },
                                    label = { Text(if (isBengali) "প্লেয়ার ইউআইডি (Player UID)" else "Player UID / Game ID") },
                                    singleLine = true,
                                    colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = EmeraldPrimary, unfocusedBorderColor = BorderLight),
                                    modifier = Modifier.fillMaxWidth()
                                )

                                Spacer(modifier = Modifier.height(10.dp))

                                Text(text = if (isBengali) "টপ-আপ প্যাকেজ নির্বাচন করুন" else "Select Package", fontSize = 12.sp, color = TextSecondary)
                                Spacer(modifier = Modifier.height(6.dp))

                                gamePackages.forEach { gPkg ->
                                    val isSelected = selectedProvider == gPkg
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(vertical = 4.dp)
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(if (isSelected) EmeraldContainer else BackgroundLight)
                                            .clickable {
                                                selectedProvider = gPkg
                                                val price = Regex("""৳(\d+)""").find(gPkg)?.groupValues?.get(1) ?: "85"
                                                amountText = price
                                            }
                                            .padding(10.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(imageVector = Icons.Default.SportsEsports, contentDescription = null, tint = EmeraldDark, modifier = Modifier.size(18.dp))
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(text = gPkg, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal, fontSize = 12.sp, color = TextPrimary)
                                    }
                                }

                                if (errorMessage != null) {
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Text(text = errorMessage!!, color = StatusFailed, fontSize = 12.sp)
                                }

                                Spacer(modifier = Modifier.height(16.dp))

                                Button(
                                    onClick = {
                                        if (recipientAccount.isBlank()) {
                                            errorMessage = if (isBengali) "প্লেয়ার আইডি লিখুন" else "Enter Player ID"
                                        } else {
                                            errorMessage = null
                                            showPinDialog = true
                                        }
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(50.dp)
                                ) {
                                    Text(text = if (isBengali) "টপ-আপ সম্পন্ন করুন" else "Complete Top-up", fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // PIN Confirmation
    if (showPinDialog) {
        val amt = amountText.toDoubleOrNull() ?: 0.0
        PinConfirmDialog(
            title = if (selectedTab == 0) (if (isBengali) "ট্রান্সফার নিশ্চিত করুন" else "Confirm Transfer")
            else if (selectedTab == 1) (if (isBengali) "বিল পরিশোধ নিশ্চিত করুন" else "Confirm Bill Payment")
            else (if (isBengali) "টপ-আপ নিশ্চিত করুন" else "Confirm Top-up"),
            subtitle = "$selectedProvider to $recipientAccount",
            amount = amt,
            isBengali = isBengali,
            onConfirm = { pin ->
                showPinDialog = false
                val res = if (selectedTab == 0) {
                    TelecomRepository.transferBalance(recipientAccount, amt, selectedWallet, pin)
                } else if (selectedTab == 1) {
                    TelecomRepository.payBillOrTopup(TransactionType.BILL_PAY, recipientAccount, amt, selectedProvider, pin)
                } else {
                    TelecomRepository.payBillOrTopup(TransactionType.GAME_TOPUP, recipientAccount, amt, selectedProvider, pin)
                }

                res.onSuccess { tx ->
                    completedTransaction = tx
                    recipientAccount = ""
                }.onFailure { err ->
                    errorMessage = err.message
                }
            },
            onDismiss = { showPinDialog = false }
        )
    }

    // Receipt Dialog
    completedTransaction?.let { tx ->
        DigitalReceiptDialog(
            transaction = tx,
            isBengali = isBengali,
            onDismiss = { completedTransaction = null }
        )
    }
}
