package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Premium Green & Gold Palette for MASUM TELECOM
val EmeraldDark = Color(0xFF064E3B)
val EmeraldPrimary = Color(0xFF047857)
val EmeraldLight = Color(0xFF10B981)
val EmeraldSoft = Color(0xFFD1FAE5)
val EmeraldContainer = Color(0xFFECFDF5)

val AmberAccent = Color(0xFFF59E0B)
val AmberLight = Color(0xFFFEF3C7)
val AmberDark = Color(0xFFB45309)

// Neutrals
val BackgroundLight = Color(0xFFF6F8FA)
val SurfaceLight = Color(0xFFFFFFFF)
val SurfaceCard = Color(0xFFFFFFFF)
val BorderLight = Color(0xFFE2E8F0)
val TextPrimary = Color(0xFF0F172A)
val TextSecondary = Color(0xFF64748B)
val TextMuted = Color(0xFF94A3B8)

// Status Colors
val StatusSuccess = Color(0xFF10B981)
val StatusSuccessBg = Color(0xFFD1FAE5)
val StatusPending = Color(0xFFF59E0B)
val StatusPendingBg = Color(0xFFFEF3C7)
val StatusProcessing = Color(0xFF3B82F6)
val StatusProcessingBg = Color(0xFFDBEAFE)
val StatusFailed = Color(0xFFEF4444)
val StatusFailedBg = Color(0xFFFEE2E2)

// Bangladeshi Telecom Operator Colors
val ColorGP = Color(0xFF0072CE)          // Grameenphone Blue
val ColorBanglalink = Color(0xFFF37021)   // Banglalink Orange
val ColorRobi = Color(0xFFED1C24)         // Robi Red
val ColorAirtel = Color(0xFFE40046)       // Airtel Red-Pink
val ColorTeletalk = Color(0xFF008836)     // Teletalk Green
val ColorBkash = Color(0xFFE2136E)        // bKash Magenta
val ColorNagad = Color(0xFFF7941D)        // Nagad Orange
val ColorRocket = Color(0xFF8C3494)       // Rocket Purple
val ColorUpay = Color(0xFF0081C9)         // Upay Cyan
