package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Notice
import com.example.data.model.Operator
import com.example.data.model.TransactionRecord
import com.example.data.model.TransactionType
import com.example.data.model.User
import com.example.ui.components.DigitalReceiptDialog
import com.example.ui.components.InteractiveWalletCard
import com.example.ui.components.NoticeMarqueeCard
import com.example.ui.components.OperatorLogoPill
import com.example.ui.components.StatusBadge
import com.example.ui.theme.AmberAccent
import com.example.ui.theme.BackgroundLight
import com.example.ui.theme.BorderLight
import com.example.ui.theme.EmeraldContainer
import com.example.ui.theme.EmeraldDark
import com.example.ui.theme.EmeraldLight
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

data class ServiceGridItem(
    val id: String,
    val titleEn: String,
    val titleBn: String,
    val icon: ImageVector,
    val color: Color,
    val badge: String? = null
)

@Composable
fun HomeScreen(
    user: User,
    notices: List<Notice>,
    transactions: List<TransactionRecord>,
    isBengali: Boolean,
    onNavigateToRecharge: () -> Unit,
    onNavigateToPackages: (isDrive: Boolean) -> Unit,
    onNavigateToAddBalance: () -> Unit,
    onNavigateToHistory: () -> Unit,
    onNavigateToServices: (serviceType: String) -> Unit,
    onSelectOperator: (Operator) -> Unit,
    onNoticeClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedTransactionForReceipt by remember { mutableStateOf<TransactionRecord?>(null) }

    val serviceItems = remember(isBengali) {
        listOf(
            ServiceGridItem(
                id = "recharge",
                titleEn = "Recharge",
                titleBn = "ফ্লেক্সিলোড",
                icon = Icons.Default.PhoneAndroid,
                color = EmeraldPrimary,
                badge = if (isBengali) "কমিশন" else "2.6%"
            ),
            ServiceGridItem(
                id = "drive",
                titleEn = "Drive Pack",
                titleBn = "ড্রাইভ অফার",
                icon = Icons.Default.Bolt,
                color = Color(0xFFD97706),
                badge = if (isBengali) "ক্যাশব্যাক" else "Offer"
            ),
            ServiceGridItem(
                id = "regular",
                titleEn = "Regular Pack",
                titleBn = "রেগুলার প্যাক",
                icon = Icons.Default.Inventory2,
                color = Color(0xFF0284C7)
            ),
            ServiceGridItem(
                id = "add_balance",
                titleEn = "Add Balance",
                titleBn = "ব্যালেন্স যোগ",
                icon = Icons.Default.AccountBalanceWallet,
                color = Color(0xFF059669)
            ),
            ServiceGridItem(
                id = "transfer",
                titleEn = "Transfer",
                titleBn = "ট্রান্সফার",
                icon = Icons.Default.SwapHoriz,
                color = Color(0xFF7C3AED)
            ),
            ServiceGridItem(
                id = "history",
                titleEn = "History",
                titleBn = "লেনদেন হিস্ট্রি",
                icon = Icons.Default.History,
                color = Color(0xFF475569)
            ),
            ServiceGridItem(
                id = "bill_pay",
                titleEn = "Bill Pay",
                titleBn = "বিদ্যুৎ/গ্যাস বিল",
                icon = Icons.Default.Receipt,
                color = Color(0xFFEA580C)
            ),
            ServiceGridItem(
                id = "game_topup",
                titleEn = "Game Topup",
                titleBn = "গেম টপ-আপ",
                icon = Icons.Default.SportsEsports,
                color = Color(0xFFDC2626)
            )
        )
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(BackgroundLight),
        contentPadding = PaddingValues(bottom = 24.dp)
    ) {
        // 1. Interactive Wallet Card
        item {
            Column(modifier = Modifier.padding(16.dp)) {
                InteractiveWalletCard(
                    user = user,
                    isBengali = isBengali,
                    onAddBalanceClick = onNavigateToAddBalance,
                    onTransferClick = { onNavigateToServices("transfer") },
                    onDrivePackClick = { onNavigateToPackages(true) },
                    onRegularPackClick = { onNavigateToPackages(false) }
                )
            }
        }

        // 2. Notice Marquee
        item {
            Box(modifier = Modifier.padding(horizontal = 16.dp, vertical = 2.dp)) {
                NoticeMarqueeCard(
                    notices = notices,
                    isBengali = isBengali,
                    onClick = onNoticeClick
                )
            }
        }

        // 3. Operators Quick Strip
        item {
            Column(modifier = Modifier.padding(top = 16.dp)) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (isBengali) "টেলিকম অপারেটর" else "Telecom Operators",
                        color = TextPrimary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp
                    )
                    Text(
                        text = if (isBengali) "সরাসরি রিচার্জ" else "Direct Recharge",
                        color = TextSecondary,
                        fontSize = 11.sp
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                LazyRow(
                    contentPadding = PaddingValues(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(Operator.entries) { operator ->
                        Card(
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(BorderLight)),
                            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                            modifier = Modifier
                                .clickable { onSelectOperator(operator) }
                                .testTag("operator_chip_${operator.id}")
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(10.dp)
                                        .clip(CircleShape)
                                        .background(operator.color)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = if (isBengali) operator.banglaName else operator.displayName,
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 12.sp,
                                    color = TextPrimary
                                )
                            }
                        }
                    }
                }
            }
        }

        // 4. Main Service Grid (8 cards)
        item {
            Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 18.dp)) {
                Text(
                    text = if (isBengali) "মূল সেবাসমূহ" else "Core Services",
                    color = TextPrimary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )

                Spacer(modifier = Modifier.height(12.dp))

                // 4x2 Grid layout
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    val chunked = serviceItems.chunked(4)
                    chunked.forEach { rowItems ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            rowItems.forEach { item ->
                                ServiceGridCard(
                                    item = item,
                                    isBengali = isBengali,
                                    modifier = Modifier.weight(1f),
                                    onClick = {
                                        when (item.id) {
                                            "recharge" -> onNavigateToRecharge()
                                            "drive" -> onNavigateToPackages(true)
                                            "regular" -> onNavigateToPackages(false)
                                            "add_balance" -> onNavigateToAddBalance()
                                            "history" -> onNavigateToHistory()
                                            "transfer" -> onNavigateToServices("transfer")
                                            "bill_pay" -> onNavigateToServices("bill_pay")
                                            "game_topup" -> onNavigateToServices("game_topup")
                                        }
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }

        // 5. Recent Transactions Header & List
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (isBengali) "সাম্প্রতিক লেনদেন" else "Recent Transactions",
                    color = TextPrimary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
                TextButton(onClick = onNavigateToHistory) {
                    Text(
                        text = if (isBengali) "সব দেখুন" else "View All",
                        color = EmeraldPrimary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                }
            }
        }

        val recentTx = transactions.take(5)
        if (recentTx.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = if (isBengali) "এখনো কোনো লেনদেন হয়নি" else "No recent transactions found",
                        color = TextMuted,
                        fontSize = 13.sp
                    )
                }
            }
        } else {
            items(recentTx) { tx ->
                RecentTransactionCard(
                    transaction = tx,
                    isBengali = isBengali,
                    onClick = { selectedTransactionForReceipt = tx },
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
                )
            }
        }
    }

    // Receipt Dialog
    selectedTransactionForReceipt?.let { tx ->
        DigitalReceiptDialog(
            transaction = tx,
            isBengali = isBengali,
            onDismiss = { selectedTransactionForReceipt = null }
        )
    }
}

@Composable
private fun ServiceGridCard(
    item: ServiceGridItem,
    isBengali: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(BorderLight)),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = modifier
            .clickable { onClick() }
            .testTag("service_card_${item.id}")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 12.dp, horizontal = 4.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Box(
                modifier = Modifier
                    .size(46.dp)
                    .clip(CircleShape)
                    .background(item.color.copy(alpha = 0.12f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = item.icon,
                    contentDescription = item.titleEn,
                    tint = item.color,
                    modifier = Modifier.size(24.dp)
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = if (isBengali) item.titleBn else item.titleEn,
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold,
                color = TextPrimary,
                textAlign = TextAlign.Center,
                maxLines = 1
            )

            if (item.badge != null) {
                Spacer(modifier = Modifier.height(4.dp))
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(item.color)
                        .padding(horizontal = 5.dp, vertical = 1.dp)
                ) {
                    Text(
                        text = item.badge,
                        color = Color.White,
                        fontSize = 8.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
private fun RecentTransactionCard(
    transaction: TransactionRecord,
    isBengali: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(BorderLight)),
        modifier = modifier
            .fillMaxWidth()
            .clickable { onClick() }
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(EmeraldContainer),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = when (transaction.type) {
                            TransactionType.RECHARGE -> Icons.Default.PhoneAndroid
                            TransactionType.DRIVE_PURCHASE -> Icons.Default.Bolt
                            TransactionType.REGULAR_PURCHASE -> Icons.Default.Inventory2
                            TransactionType.ADD_BALANCE -> Icons.Default.AccountBalanceWallet
                            TransactionType.BALANCE_TRANSFER -> Icons.Default.SwapHoriz
                            TransactionType.BILL_PAY -> Icons.Default.Receipt
                            TransactionType.GAME_TOPUP -> Icons.Default.SportsEsports
                        },
                        contentDescription = "Type",
                        tint = EmeraldDark,
                        modifier = Modifier.size(20.dp)
                    )
                }

                Spacer(modifier = Modifier.width(10.dp))

                Column {
                    Text(
                        text = transaction.recipientNumber,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = TextPrimary
                    )
                    Text(
                        text = transaction.details,
                        fontSize = 11.sp,
                        color = TextSecondary,
                        maxLines = 1
                    )
                }
            }

            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = "৳ ${"%.2f".format(transaction.amount)}",
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = EmeraldDark
                )
                Spacer(modifier = Modifier.height(4.dp))
                StatusBadge(status = transaction.status, isBengali = isBengali)
            }
        }
    }
}
