package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.CardGiftcard
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Operator
import com.example.data.model.PackageCategory
import com.example.data.model.PackageType
import com.example.data.model.TelecomPackage
import com.example.data.model.TransactionRecord
import com.example.data.model.User
import com.example.data.repository.TelecomRepository
import com.example.ui.components.DigitalReceiptDialog
import com.example.ui.components.OperatorLogoPill
import com.example.ui.theme.AmberAccent
import com.example.ui.theme.AmberLight
import com.example.ui.theme.BackgroundLight
import com.example.ui.theme.BorderLight
import com.example.ui.theme.EmeraldContainer
import com.example.ui.theme.EmeraldDark
import com.example.ui.theme.EmeraldLight
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.EmeraldSoft
import com.example.ui.theme.StatusFailed
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun PackageScreen(
    user: User,
    packages: List<TelecomPackage>,
    isBengali: Boolean,
    initialPackageType: PackageType = PackageType.DRIVE,
    modifier: Modifier = Modifier
) {
    var selectedPackageType by remember { mutableStateOf(initialPackageType) }
    var selectedOperatorFilter by remember { mutableStateOf<Operator?>(null) }
    var selectedCategoryFilter by remember { mutableStateOf(PackageCategory.ALL) }
    var packageToBuy by remember { mutableStateOf<TelecomPackage?>(null) }
    var completedTransaction by remember { mutableStateOf<TransactionRecord?>(null) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    val filteredPackages = packages.filter { pkg ->
        pkg.packageType == selectedPackageType &&
                (selectedOperatorFilter == null || pkg.operator == selectedOperatorFilter) &&
                (selectedCategoryFilter == PackageCategory.ALL || pkg.category == selectedCategoryFilter) &&
                pkg.isActive
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(BackgroundLight)
    ) {
        // Top Segmented Switcher: Drive vs Regular
        Surface(
            color = Color.White,
            shadowElevation = 2.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(top = 8.dp)) {
                TabRow(
                    selectedTabIndex = if (selectedPackageType == PackageType.DRIVE) 0 else 1,
                    containerColor = Color.White,
                    contentColor = EmeraldPrimary,
                    indicator = { tabPositions ->
                        TabRowDefaults.SecondaryIndicator(
                            modifier = Modifier.tabIndicatorOffset(
                                tabPositions[if (selectedPackageType == PackageType.DRIVE) 0 else 1]
                            ),
                            color = EmeraldPrimary,
                            height = 3.dp
                        )
                    }
                ) {
                    Tab(
                        selected = selectedPackageType == PackageType.DRIVE,
                        onClick = { selectedPackageType = PackageType.DRIVE },
                        text = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(imageVector = Icons.Default.Bolt, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = if (isBengali) "ড্রাইভ অফার (ক্যাশব্যাক)" else "Drive Offers (Cashback)",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp
                                )
                            }
                        }
                    )
                    Tab(
                        selected = selectedPackageType == PackageType.REGULAR,
                        onClick = { selectedPackageType = PackageType.REGULAR },
                        text = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(imageVector = Icons.Default.Inventory2, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = if (isBengali) "রেগুলার প্যাকেজ" else "Regular Packages",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp
                                )
                            }
                        }
                    )
                }

                // Operator filter chips
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    item {
                        FilterPill(
                            label = if (isBengali) "সকল" else "All",
                            isSelected = selectedOperatorFilter == null,
                            onClick = { selectedOperatorFilter = null }
                        )
                    }
                    items(Operator.entries) { op ->
                        FilterPill(
                            label = if (isBengali) op.banglaName else op.displayName,
                            isSelected = selectedOperatorFilter == op,
                            accentColor = op.color,
                            onClick = { selectedOperatorFilter = op }
                        )
                    }
                }

                // Category filter chips
                LazyRow(
                    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 10.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    items(PackageCategory.entries) { cat ->
                        FilterPill(
                            label = if (isBengali) cat.banglaName else cat.displayName,
                            isSelected = selectedCategoryFilter == cat,
                            onClick = { selectedCategoryFilter = cat }
                        )
                    }
                }
            }
        }

        // Packages List
        if (filteredPackages.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(imageVector = Icons.Default.Inventory2, contentDescription = null, tint = TextMuted, modifier = Modifier.size(48.dp))
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = if (isBengali) "এই ক্যাটাগরিতে কোনো প্যাকেজ পাওয়া যায়নি" else "No packages available for this selection",
                        color = TextSecondary,
                        fontSize = 13.sp
                    )
                }
            }
        } else {
            LazyColumn(
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(filteredPackages) { pkg ->
                    PackageItemCard(
                        pkg = pkg,
                        isBengali = isBengali,
                        onBuyClick = { packageToBuy = pkg }
                    )
                }
            }
        }
    }

    // Buy Dialog (Recipient Number + PIN)
    packageToBuy?.let { pkg ->
        BuyPackageDialog(
            pkg = pkg,
            user = user,
            isBengali = isBengali,
            onConfirm = { recipient, pin ->
                val res = TelecomRepository.purchasePackage(
                    packageItem = pkg,
                    recipientNumber = recipient,
                    pin = pin
                )
                res.onSuccess { tx ->
                    packageToBuy = null
                    completedTransaction = tx
                }.onFailure { err ->
                    errorMessage = err.message
                }
            },
            onDismiss = {
                packageToBuy = null
                errorMessage = null
            },
            errorMessage = errorMessage
        )
    }

    // Receipt Dialog on Success
    completedTransaction?.let { tx ->
        DigitalReceiptDialog(
            transaction = tx,
            isBengali = isBengali,
            onDismiss = { completedTransaction = null }
        )
    }
}

@Composable
private fun FilterPill(
    label: String,
    isSelected: Boolean,
    accentColor: Color = EmeraldPrimary,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(20.dp))
            .background(if (isSelected) accentColor else Color.White)
            .border(1.dp, if (isSelected) accentColor else BorderLight, RoundedCornerShape(20.dp))
            .clickable { onClick() }
            .padding(horizontal = 12.dp, vertical = 6.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            color = if (isSelected) Color.White else TextPrimary,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
            fontSize = 11.sp
        )
    }
}

@Composable
private fun PackageItemCard(
    pkg: TelecomPackage,
    isBengali: Boolean,
    onBuyClick: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(BorderLight)),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // Header Row: Operator Logo & Eligibility
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                OperatorLogoPill(operator = pkg.operator, isBengali = isBengali)

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(EmeraldContainer)
                        .padding(horizontal = 8.dp, vertical = 3.dp)
                ) {
                    Text(
                        text = pkg.eligibleDivision,
                        color = EmeraldDark,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Package Title
            Text(
                text = if (isBengali) pkg.titleBn else pkg.title,
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp,
                color = TextPrimary
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Badges Row: Volume, Minutes, Validity
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (pkg.dataVolume != "0 GB") {
                    PillBadge(text = pkg.dataVolume, color = EmeraldPrimary)
                }
                if (pkg.minutes != "0 Min") {
                    PillBadge(text = pkg.minutes, color = Color(0xFF0284C7))
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(imageVector = Icons.Default.Schedule, contentDescription = null, tint = TextMuted, modifier = Modifier.size(13.dp))
                    Spacer(modifier = Modifier.width(3.dp))
                    Text(
                        text = if (isBengali) pkg.validityBn else pkg.validity,
                        fontSize = 11.sp,
                        color = TextSecondary
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Price and Buy Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.Bottom) {
                    Text(
                        text = "৳ ${"%.0f".format(pkg.offerPrice)}",
                        color = EmeraldDark,
                        fontWeight = FontWeight.Bold,
                        fontSize = 20.sp
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "৳ ${"%.0f".format(pkg.regularPrice)}",
                        color = TextMuted,
                        fontSize = 13.sp,
                        textDecoration = TextDecoration.LineThrough
                    )

                    if (pkg.commission > 0) {
                        Spacer(modifier = Modifier.width(8.dp))
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(AmberLight)
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = if (isBengali) "৳${"%.0f".format(pkg.commission)} ক্যাশব্যাক" else "৳${"%.0f".format(pkg.commission)} Cashback",
                                color = Color(0xFFB45309),
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                Button(
                    onClick = onBuyClick,
                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                    shape = RoundedCornerShape(10.dp),
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 6.dp),
                    modifier = Modifier.testTag("buy_package_btn_${pkg.id}")
                ) {
                    Icon(imageVector = Icons.Default.ShoppingCart, contentDescription = null, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (isBengali) "কিনুন" else "Buy",
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                }
            }
        }
    }
}

@Composable
private fun PillBadge(text: String, color: Color) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(6.dp))
            .background(color.copy(alpha = 0.12f))
            .padding(horizontal = 8.dp, vertical = 3.dp)
    ) {
        Text(text = text, color = color, fontSize = 11.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun BuyPackageDialog(
    pkg: TelecomPackage,
    user: User,
    isBengali: Boolean,
    onConfirm: (recipient: String, pin: String) -> Unit,
    onDismiss: () -> Unit,
    errorMessage: String?
) {
    var recipientPhone by remember { mutableStateOf("") }
    var pin by remember { mutableStateOf("") }
    var localError by remember { mutableStateOf<String?>(null) }

    val walletBalance = if (pkg.packageType == PackageType.DRIVE) user.balanceDrive else user.balanceMain
    val walletLabel = if (pkg.packageType == PackageType.DRIVE) {
        if (isBengali) "ড্রাইভ ব্যালেন্স" else "Drive Wallet"
    } else {
        if (isBengali) "মেইন ব্যালেন্স" else "Main Wallet"
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = if (isBengali) "প্যাকেজ ক্রয়ের বিবরণ" else "Confirm Package Purchase",
                fontWeight = FontWeight.Bold,
                color = EmeraldDark,
                fontSize = 17.sp
            )
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = EmeraldContainer,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(text = if (isBengali) pkg.titleBn else pkg.title, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = EmeraldDark)
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(text = if (isBengali) "মূল্য: ৳${"%.0f".format(pkg.offerPrice)}" else "Price: ৳${"%.0f".format(pkg.offerPrice)}", fontWeight = FontWeight.Bold, color = EmeraldPrimary, fontSize = 12.sp)
                            Text(text = "$walletLabel: ৳${"%.2f".format(walletBalance)}", fontSize = 11.sp, color = TextSecondary)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                OutlinedTextField(
                    value = recipientPhone,
                    onValueChange = {
                        if (it.length <= 11 && it.all { ch -> ch.isDigit() }) {
                            recipientPhone = it
                            localError = null
                        }
                    },
                    label = { Text(if (isBengali) "গ্রাহকের ফোন নম্বর (১১ ডিজিট)" else "Recipient Phone Number") },
                    placeholder = { Text("01XXXXXXXXX") },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = EmeraldPrimary,
                        unfocusedBorderColor = BorderLight
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("package_recipient_input")
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = pin,
                    onValueChange = {
                        if (it.length <= 6 && it.all { ch -> ch.isDigit() }) {
                            pin = it
                            localError = null
                        }
                    },
                    label = { Text(if (isBengali) "আপনার ৪ ডিজিট পিন" else "Enter 4-Digit PIN") },
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = EmeraldPrimary,
                        unfocusedBorderColor = BorderLight
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("package_pin_input")
                )

                val displayErr = errorMessage ?: localError
                if (displayErr != null) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(text = displayErr, color = StatusFailed, fontSize = 11.sp, fontWeight = FontWeight.Medium)
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (recipientPhone.length != 11 || !recipientPhone.startsWith("01")) {
                        localError = if (isBengali) "সঠিক ১১ ডিজিটের ফোন নম্বর দিন" else "Enter valid 11-digit phone number"
                    } else if (pin.length < 4) {
                        localError = if (isBengali) "৪ ডিজিটের সঠিক পিন লিখুন" else "Enter 4-digit PIN"
                    } else {
                        localError = null
                        onConfirm(recipientPhone, pin)
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary),
                modifier = Modifier.testTag("confirm_package_purchase_btn")
            ) {
                Text(if (isBengali) "অর্ডার সম্পন্ন করুন" else "Confirm Order")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(if (isBengali) "বাতিল" else "Cancel", color = TextSecondary)
            }
        }
    )
}
