package com.example.data.model

import androidx.compose.ui.graphics.Color
import com.example.ui.theme.ColorAirtel
import com.example.ui.theme.ColorBanglalink
import com.example.ui.theme.ColorBkash
import com.example.ui.theme.ColorGP
import com.example.ui.theme.ColorNagad
import com.example.ui.theme.ColorRobi
import com.example.ui.theme.ColorRocket
import com.example.ui.theme.ColorTeletalk
import com.example.ui.theme.ColorUpay
import com.example.ui.theme.StatusFailed
import com.example.ui.theme.StatusPending
import com.example.ui.theme.StatusProcessing
import com.example.ui.theme.StatusSuccess

enum class Operator(
    val id: String,
    val displayName: String,
    val banglaName: String,
    val color: Color,
    val prefixes: List<String>
) {
    GRAMEENPHONE("gp", "Grameenphone", "গ্রামীণফোন", ColorGP, listOf("017", "013")),
    ROBI("robi", "Robi", "রবি", ColorRobi, listOf("018")),
    BANGLALINK("bl", "Banglalink", "বাংলালিংক", ColorBanglalink, listOf("019", "014")),
    AIRTEL("airtel", "Airtel", "এয়ারটেল", ColorAirtel, listOf("016")),
    TELETALK("teletalk", "Teletalk", "টেলিটক", ColorTeletalk, listOf("015"));

    companion object {
        fun detectFromNumber(number: String): Operator? {
            val clean = number.trim().replace("+88", "").replace(" ", "").replace("-", "")
            if (clean.length < 3) return null
            val prefix = clean.substring(0, 3)
            return entries.find { it.prefixes.contains(prefix) }
        }
    }
}

enum class UserRole(val displayName: String, val banglaName: String, val commissionRate: Double) {
    SUB_ADMIN("Sub-Admin", "সাব-এডমিন", 3.2),
    HOUSE("House", "হাউস", 3.0),
    DGR("DGR", "ডিজিআর", 2.8),
    DEALER("Dealer", "ডিলার", 2.6),
    RETAILER("Retailer", "রিটেইলার", 2.4),
    ADMIN("Admin", "এডমিন", 0.0)
}

enum class BalanceType(val displayName: String, val banglaName: String) {
    MAIN("Main Balance", "মূল ব্যালেন্স"),
    DRIVE("Drive Balance", "ড্রাইভ ব্যালেন্স"),
    BANK("Bank Balance", "ব্যাংক ব্যালেন্স")
}

enum class PackageType(val displayName: String, val banglaName: String) {
    DRIVE("Drive Package", "ড্রাইভ প্যাক"),
    REGULAR("Regular Package", "রেগুলার প্যাক")
}

enum class PackageCategory(val displayName: String, val banglaName: String) {
    ALL("All", "সকল"),
    INTERNET("Internet", "ইন্টারনেট"),
    MINUTES("Minutes", "মিনিট"),
    COMBO("Combo / Bundle", "বান্ডেল"),
    SMS("SMS", "এসএমএস")
}

enum class OrderStatus(val displayName: String, val banglaName: String, val color: Color) {
    PENDING("Pending", "অপেক্ষমান", StatusPending),
    PROCESSING("Processing", "প্রক্রিয়াধীন", StatusProcessing),
    SUCCESSFUL("Successful", "সফল", StatusSuccess),
    FAILED("Failed", "ব্যর্থ", StatusFailed),
    REFUNDED("Refunded", "ফেরত", StatusFailed)
}

enum class TransactionType(val displayName: String, val banglaName: String) {
    RECHARGE("Mobile Recharge", "মোবাইল রিচার্জ"),
    DRIVE_PURCHASE("Drive Package", "ড্রাইভ প্যাকেজ"),
    REGULAR_PURCHASE("Regular Package", "রেগুলার প্যাকেজ"),
    ADD_BALANCE("Add Balance", "ব্যালেন্স জমা"),
    BALANCE_TRANSFER("Balance Transfer", "ব্যালেন্স ট্রান্সফার"),
    BILL_PAY("Bill Payment", "বিল পরিশোধ"),
    GAME_TOPUP("Game Top-up", "গেম টপ-আপ")
}

enum class PaymentMethod(val displayName: String, val banglaName: String, val color: Color, val number: String) {
    BKASH("bKash", "বিকাশ", ColorBkash, "01712345678"),
    NAGAD("Nagad", "নগদ", ColorNagad, "01812345678"),
    ROCKET("Rocket", "রকেট", ColorRocket, "01912345678"),
    UPAY("Upay", "উপায়", ColorUpay, "01612345678")
}

data class User(
    val id: String,
    val name: String,
    val phone: String,
    val email: String,
    val role: UserRole,
    val balanceMain: Double = 500.0,
    val balanceDrive: Double = 1200.0,
    val balanceBank: Double = 250.0,
    val pin: String = "1234",
    val isActive: Boolean = true,
    val createdAt: Long = System.currentTimeMillis()
)

data class TelecomPackage(
    val id: String,
    val operator: Operator,
    val title: String,
    val titleBn: String,
    val dataVolume: String,
    val minutes: String,
    val sms: String,
    val validity: String,
    val validityBn: String,
    val regularPrice: Double,
    val offerPrice: Double,
    val commission: Double,
    val category: PackageCategory,
    val packageType: PackageType,
    val eligibleDivision: String = "সমগ্র বাংলাদেশ (All BD)",
    val isActive: Boolean = true
)

data class TransactionRecord(
    val id: String,
    val trxId: String,
    val userId: String,
    val userName: String,
    val userPhone: String,
    val userRole: UserRole,
    val type: TransactionType,
    val operator: Operator?,
    val recipientNumber: String,
    val amount: Double,
    val commissionEarned: Double = 0.0,
    val balanceType: BalanceType,
    val status: OrderStatus,
    val details: String,
    val timestamp: Long = System.currentTimeMillis(),
    val paymentMethod: PaymentMethod? = null,
    val failureReason: String? = null
)

data class AddBalanceRequest(
    val id: String,
    val userId: String,
    val userName: String,
    val userPhone: String,
    val method: PaymentMethod,
    val senderNumber: String,
    val trxId: String,
    val amount: Double,
    val balanceType: BalanceType,
    val status: OrderStatus = OrderStatus.PENDING,
    val requestTime: Long = System.currentTimeMillis(),
    val note: String = ""
)

data class Notice(
    val id: String,
    val title: String,
    val textEn: String,
    val textBn: String,
    val timestamp: Long = System.currentTimeMillis(),
    val isActive: Boolean = true
)

data class TelecomApiConfig(
    val baseUrl: String = "https://api.masumtelecom.com/v1",
    val apiKey: String = "mt_live_key_984712",
    val apiSecret: String = "mt_sec_00293189",
    val isDemoMode: Boolean = true
)

data class AdminLedgerStats(
    val totalDealers: Int,
    val totalSystemBalance: Double,
    val todaySalesVolume: Double,
    val pendingOrdersCount: Int,
    val pendingAddBalanceCount: Int,
    val successfulOrdersCount: Int
)
