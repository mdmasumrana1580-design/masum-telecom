package com.example.data.repository

import com.example.data.model.AddBalanceRequest
import com.example.data.model.AdminLedgerStats
import com.example.data.model.BalanceType
import com.example.data.model.Notice
import com.example.data.model.Operator
import com.example.data.model.OrderStatus
import com.example.data.model.PackageCategory
import com.example.data.model.PackageType
import com.example.data.model.PaymentMethod
import com.example.data.model.TelecomApiConfig
import com.example.data.model.TelecomPackage
import com.example.data.model.TransactionRecord
import com.example.data.model.TransactionType
import com.example.data.model.User
import com.example.data.model.UserRole
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.util.UUID

object TelecomRepository {

    private val repositoryScope = CoroutineScope(Dispatchers.Default)

    // Language state: true for Bengali (বাংলা), false for English
    private val _isBengali = MutableStateFlow(true)
    val isBengali: StateFlow<Boolean> = _isBengali.asStateFlow()

    // Config state
    private val _apiConfig = MutableStateFlow(TelecomApiConfig())
    val apiConfig: StateFlow<TelecomApiConfig> = _apiConfig.asStateFlow()

    // Notices
    private val _notices = MutableStateFlow(
        listOf(
            Notice(
                id = "n1",
                title = "ঈদ স্পেশাল ড্রাইভ অফার!",
                textEn = "Welcome to MASUM TELECOM. Enjoy up to ৳250 cashback on GP, Robi, and Banglalink 30-day drive packs today!",
                textBn = "মাসুম টেলিকমে স্বাগতম! রবি, জিপি ও বাংলালিংক ৩০ দিনের ড্রাইভ প্যাকে পাচ্ছেন সর্বোচ্চ ২৫০ টাকা পর্যন্ত স্পেশাল ক্যাশব্যাক। যেকোনো প্রয়োজনে হেল্পলাইনে যোগাযোগ করুন।"
            ),
            Notice(
                id = "n2",
                title = "সার্ভার আপডেট নোটিশ",
                textEn = "Flexiload and Drive server running at 100% automated speed. Balance add requests are auto-verified within 2-5 minutes.",
                textBn = "ফ্লেক্সিলোড ও ড্রাইভ সার্ভার শতভাগ দ্রুত ও সক্রিয় রয়েছে। ব্যালেন্স অ্যাড করার পর সর্বোচ্চ ২-৫ মিনিটের মধ্যে অনুমোদন নিশ্চিত করা হয়।"
            )
        )
    )
    val notices: StateFlow<List<Notice>> = _notices.asStateFlow()

    // Seed Users (Admin & Dealers)
    private val defaultAdmin = User(
        id = "admin_01",
        name = "Masum Rana (Admin)",
        phone = "01700000000",
        email = "admin@masumtelecom.com",
        role = UserRole.ADMIN,
        balanceMain = 50000.0,
        balanceDrive = 100000.0,
        balanceBank = 50000.0,
        pin = "1234"
    )

    private val defaultDealer = User(
        id = "dealer_01",
        name = "Rana Telecom Service",
        phone = "01711223344",
        email = "dealer@masumtelecom.com",
        role = UserRole.DEALER,
        balanceMain = 1580.0,
        balanceDrive = 3450.0,
        balanceBank = 620.0,
        pin = "1234"
    )

    private val defaultRetailer = User(
        id = "retailer_01",
        name = "Sujon Store",
        phone = "01855667788",
        email = "retailer@masumtelecom.com",
        role = UserRole.RETAILER,
        balanceMain = 850.0,
        balanceDrive = 1200.0,
        balanceBank = 300.0,
        pin = "1234"
    )

    private val _users = MutableStateFlow<List<User>>(listOf(defaultAdmin, defaultDealer, defaultRetailer))
    val users: StateFlow<List<User>> = _users.asStateFlow()

    private val _currentUser = MutableStateFlow<User?>(defaultDealer)
    val currentUser: StateFlow<User?> = _currentUser.asStateFlow()

    // Preloaded Bangladesh Telecom Packages (40+ real packs for GP, Robi, BL, Airtel, Teletalk)
    private val _packages = MutableStateFlow<List<TelecomPackage>>(generateInitialPackages())
    val packages: StateFlow<List<TelecomPackage>> = _packages.asStateFlow()

    // Transactions History
    private val _transactions = MutableStateFlow<List<TransactionRecord>>(generateInitialTransactions())
    val transactions: StateFlow<List<TransactionRecord>> = _transactions.asStateFlow()

    // Add Balance Requests
    private val _addBalanceRequests = MutableStateFlow<List<AddBalanceRequest>>(generateInitialAddBalanceRequests())
    val addBalanceRequests: StateFlow<List<AddBalanceRequest>> = _addBalanceRequests.asStateFlow()

    fun toggleLanguage() {
        _isBengali.update { !it }
    }

    fun setLanguage(bengali: Boolean) {
        _isBengali.value = bengali
    }

    fun switchUser(userId: String): Boolean {
        val user = _users.value.find { it.id == userId }
        if (user != null) {
            _currentUser.value = user
            return true
        }
        return false
    }

    fun login(phone: String, pin: String): Result<User> {
        val cleanPhone = phone.trim().replace("+88", "").replace(" ", "").replace("-", "")
        val user = _users.value.find { it.phone == cleanPhone }
            ?: return Result.failure(Exception(if (_isBengali.value) "ফোন নম্বরটি নিবন্ধিত নয়" else "Phone number not registered"))

        if (!user.isActive) {
            return Result.failure(Exception(if (_isBengali.value) "আপনার একাউন্টটি সাময়িকভাবে স্থগিত আছে" else "Your account is temporarily suspended"))
        }

        if (user.pin != pin.trim()) {
            return Result.failure(Exception(if (_isBengali.value) "ভুল পিন কোড দেওয়া হয়েছে" else "Incorrect 4-digit PIN"))
        }

        _currentUser.value = user
        return Result.success(user)
    }

    fun register(name: String, phone: String, email: String, role: UserRole, pin: String): Result<User> {
        val cleanPhone = phone.trim().replace("+88", "").replace(" ", "").replace("-", "")
        if (cleanPhone.length != 11 || !cleanPhone.startsWith("01")) {
            return Result.failure(Exception(if (_isBengali.value) "সঠিক ১১ ডিজিটের ফোন নম্বর দিন (যেমন: 017xxxxxxxx)" else "Please enter valid 11-digit phone number (e.g. 017xxxxxxxx)"))
        }

        if (_users.value.any { it.phone == cleanPhone }) {
            return Result.failure(Exception(if (_isBengali.value) "এই নম্বর দিয়ে ইতিমধ্যে একাউন্ট রয়েছে" else "An account already exists with this phone number"))
        }

        if (pin.length < 4) {
            return Result.failure(Exception(if (_isBengali.value) "কমপক্ষে ৪ ডিজিটের পিন কোড দিন" else "PIN must be at least 4 digits"))
        }

        val newUser = User(
            id = "user_" + UUID.randomUUID().toString().substring(0, 8),
            name = name.ifBlank { "Dealer User" },
            phone = cleanPhone,
            email = email.ifBlank { "$cleanPhone@masumtelecom.com" },
            role = role,
            balanceMain = 100.0, // Welcome bonus
            balanceDrive = 200.0,
            balanceBank = 0.0,
            pin = pin.trim(),
            isActive = true
        )

        _users.update { it + newUser }
        _currentUser.value = newUser
        return Result.success(newUser)
    }

    fun logout() {
        _currentUser.value = null
    }

    // Recharge execution with balance deduction and commission calculation
    fun executeRecharge(
        recipientNumber: String,
        amount: Double,
        operator: Operator,
        connectionType: String,
        pin: String
    ): Result<TransactionRecord> {
        val user = _currentUser.value ?: return Result.failure(Exception("Not logged in"))
        val cleanRecipient = recipientNumber.trim().replace("+88", "").replace(" ", "").replace("-", "")

        if (cleanRecipient.length != 11 || !cleanRecipient.startsWith("01")) {
            return Result.failure(Exception(if (_isBengali.value) "সঠিক ১১ ডিজিটের প্রাপক নম্বর দিন" else "Invalid 11-digit recipient phone number"))
        }

        if (amount < 10.0 || amount > 5000.0) {
            return Result.failure(Exception(if (_isBengali.value) "রিচার্জের পরিমাণ ১০ থেকে ৫০০০ টাকার মধ্যে হতে হবে" else "Amount must be between ৳10 and ৳5000"))
        }

        if (user.pin != pin.trim()) {
            return Result.failure(Exception(if (_isBengali.value) "ভুল পিন কোড" else "Incorrect PIN"))
        }

        if (user.balanceMain < amount) {
            return Result.failure(
                Exception(
                    if (_isBengali.value) "আপনার মেইন ব্যালেন্সে পর্যাপ্ত টাকা নেই (বর্তমান: ৳${"%.2f".format(user.balanceMain)})"
                    else "Insufficient main wallet balance (Current: ৳${"%.2f".format(user.balanceMain)})"
                )
            )
        }

        // Calculate commission
        val commissionRate = user.role.commissionRate
        val commissionEarned = (amount * commissionRate) / 100.0

        // Deduct from user's main wallet (and add commission cash incentive)
        val netDeduction = amount - commissionEarned
        _users.update { userList ->
            userList.map {
                if (it.id == user.id) {
                    it.copy(balanceMain = it.balanceMain - netDeduction)
                } else it
            }
        }
        _currentUser.update { it?.copy(balanceMain = it.balanceMain - netDeduction) }

        val trxId = "MTX" + (10000000..99999999).random()
        val tx = TransactionRecord(
            id = UUID.randomUUID().toString(),
            trxId = trxId,
            userId = user.id,
            userName = user.name,
            userPhone = user.phone,
            userRole = user.role,
            type = TransactionType.RECHARGE,
            operator = operator,
            recipientNumber = cleanRecipient,
            amount = amount,
            commissionEarned = commissionEarned,
            balanceType = BalanceType.MAIN,
            status = OrderStatus.PENDING,
            details = "$connectionType Flexiload (${operator.displayName})"
        )

        _transactions.update { listOf(tx) + it }

        // Simulate Telecom Gateway Processing
        repositoryScope.launch {
            delay(1500)
            _transactions.update { list ->
                list.map { if (it.id == tx.id) it.copy(status = OrderStatus.PROCESSING) else it }
            }
            delay(2000)
            _transactions.update { list ->
                list.map { if (it.id == tx.id) it.copy(status = OrderStatus.SUCCESSFUL) else it }
            }
        }

        return Result.success(tx)
    }

    // Purchase Package (Drive or Regular)
    fun purchasePackage(
        packageItem: TelecomPackage,
        recipientNumber: String,
        pin: String
    ): Result<TransactionRecord> {
        val user = _currentUser.value ?: return Result.failure(Exception("Not logged in"))
        val cleanRecipient = recipientNumber.trim().replace("+88", "").replace(" ", "").replace("-", "")

        if (cleanRecipient.length != 11 || !cleanRecipient.startsWith("01")) {
            return Result.failure(Exception(if (_isBengali.value) "সঠিক ১১ ডিজিটের গ্রাহক নম্বর লিখুন" else "Invalid 11-digit recipient phone number"))
        }

        if (user.pin != pin.trim()) {
            return Result.failure(Exception(if (_isBengali.value) "ভুল পিন কোড" else "Incorrect PIN"))
        }

        val requiredBalance = packageItem.offerPrice
        val walletType = if (packageItem.packageType == PackageType.DRIVE) BalanceType.DRIVE else BalanceType.MAIN
        val currentWalletBalance = if (walletType == BalanceType.DRIVE) user.balanceDrive else user.balanceMain

        if (currentWalletBalance < requiredBalance) {
            val walletName = if (_isBengali.value) walletType.banglaName else walletType.displayName
            return Result.failure(
                Exception(
                    if (_isBengali.value) "আপনার $walletName-এ পর্যাপ্ত টাকা নেই (প্রয়োজন ৳${packageItem.offerPrice}, বর্তমান ৳${"%.2f".format(currentWalletBalance)})"
                    else "Insufficient $walletName (Needed ৳${packageItem.offerPrice}, Current ৳${"%.2f".format(currentWalletBalance)})"
                )
            )
        }

        // Deduct cost from respective wallet
        _users.update { list ->
            list.map {
                if (it.id == user.id) {
                    if (walletType == BalanceType.DRIVE) {
                        it.copy(balanceDrive = it.balanceDrive - requiredBalance)
                    } else {
                        it.copy(balanceMain = it.balanceMain - requiredBalance)
                    }
                } else it
            }
        }
        _currentUser.update { current ->
            current?.let {
                if (walletType == BalanceType.DRIVE) {
                    it.copy(balanceDrive = it.balanceDrive - requiredBalance)
                } else {
                    it.copy(balanceMain = it.balanceMain - requiredBalance)
                }
            }
        }

        val trxId = "PKG" + (10000000..99999999).random()
        val tx = TransactionRecord(
            id = UUID.randomUUID().toString(),
            trxId = trxId,
            userId = user.id,
            userName = user.name,
            userPhone = user.phone,
            userRole = user.role,
            type = if (packageItem.packageType == PackageType.DRIVE) TransactionType.DRIVE_PURCHASE else TransactionType.REGULAR_PURCHASE,
            operator = packageItem.operator,
            recipientNumber = cleanRecipient,
            amount = packageItem.offerPrice,
            commissionEarned = packageItem.commission,
            balanceType = walletType,
            status = OrderStatus.PENDING,
            details = "${packageItem.title} - ${packageItem.validity}"
        )

        _transactions.update { listOf(tx) + it }

        // Process order
        repositoryScope.launch {
            delay(1500)
            _transactions.update { list ->
                list.map { if (it.id == tx.id) it.copy(status = OrderStatus.PROCESSING) else it }
            }
            delay(2500)
            _transactions.update { list ->
                list.map { if (it.id == tx.id) it.copy(status = OrderStatus.SUCCESSFUL) else it }
            }
        }

        return Result.success(tx)
    }

    // Submit Add Balance Request (Never updates balance directly!)
    fun submitAddBalanceRequest(
        method: PaymentMethod,
        senderNumber: String,
        trxId: String,
        amount: Double,
        balanceType: BalanceType,
        note: String
    ): Result<AddBalanceRequest> {
        val user = _currentUser.value ?: return Result.failure(Exception("Not logged in"))
        val cleanSender = senderNumber.trim().replace("+88", "").replace(" ", "").replace("-", "")

        if (cleanSender.length != 11) {
            return Result.failure(Exception(if (_isBengali.value) "সঠিক প্রেরক নম্বর লিখুন" else "Invalid sender phone number"))
        }

        if (trxId.trim().length < 6) {
            return Result.failure(Exception(if (_isBengali.value) "সঠিক ট্রানজেকশন আইডি (TrxID) লিখুন" else "Please enter valid TrxID"))
        }

        if (amount < 20.0) {
            return Result.failure(Exception(if (_isBengali.value) "সর্বনিম্ন ব্যালেন্স জমার পরিমাণ ২০ টাকা" else "Minimum add balance amount is ৳20"))
        }

        // Check duplicate TrxID
        if (_addBalanceRequests.value.any { it.trxId.equals(trxId.trim(), ignoreCase = true) }) {
            return Result.failure(Exception(if (_isBengali.value) "এই ট্রানজেকশন আইডিটি ইতিমধ্যে ব্যবহৃত হয়েছে" else "This TrxID has already been submitted"))
        }

        val request = AddBalanceRequest(
            id = UUID.randomUUID().toString(),
            userId = user.id,
            userName = user.name,
            userPhone = user.phone,
            method = method,
            senderNumber = cleanSender,
            trxId = trxId.trim().uppercase(),
            amount = amount,
            balanceType = balanceType,
            status = OrderStatus.PENDING,
            note = note.trim()
        )

        _addBalanceRequests.update { listOf(request) + it }

        // Also record a pending transaction in history
        val historyRecord = TransactionRecord(
            id = UUID.randomUUID().toString(),
            trxId = request.trxId,
            userId = user.id,
            userName = user.name,
            userPhone = user.phone,
            userRole = user.role,
            type = TransactionType.ADD_BALANCE,
            operator = null,
            recipientNumber = cleanSender,
            amount = amount,
            balanceType = balanceType,
            status = OrderStatus.PENDING,
            details = "${method.displayName} Add Balance Request",
            paymentMethod = method
        )
        _transactions.update { listOf(historyRecord) + it }

        return Result.success(request)
    }

    // Balance Transfer between dealers
    fun transferBalance(
        receiverPhone: String,
        amount: Double,
        balanceType: BalanceType,
        pin: String
    ): Result<TransactionRecord> {
        val user = _currentUser.value ?: return Result.failure(Exception("Not logged in"))
        val cleanReceiver = receiverPhone.trim().replace("+88", "").replace(" ", "").replace("-", "")

        if (cleanReceiver == user.phone) {
            return Result.failure(Exception(if (_isBengali.value) "নিজের নম্বরে ট্রান্সফার সম্ভব নয়" else "Cannot transfer to own number"))
        }

        val receiver = _users.value.find { it.phone == cleanReceiver }
            ?: return Result.failure(Exception(if (_isBengali.value) "প্রাপক ডিলারের নম্বরটি সিস্টেমে পাওয়া যায়নি" else "Receiver dealer not found"))

        if (amount < 50.0) {
            return Result.failure(Exception(if (_isBengali.value) "সর্বনিম্ন ট্রান্সফার পরিমাণ ৫০ টাকা" else "Minimum transfer amount is ৳50"))
        }

        if (user.pin != pin.trim()) {
            return Result.failure(Exception(if (_isBengali.value) "ভুল পিন কোড" else "Incorrect PIN"))
        }

        val senderBalance = when (balanceType) {
            BalanceType.MAIN -> user.balanceMain
            BalanceType.DRIVE -> user.balanceDrive
            BalanceType.BANK -> user.balanceBank
        }

        if (senderBalance < amount) {
            return Result.failure(Exception(if (_isBengali.value) "পর্যাপ্ত ব্যালেন্স নেই" else "Insufficient balance"))
        }

        // Transfer funds
        _users.update { list ->
            list.map {
                when (it.id) {
                    user.id -> {
                        when (balanceType) {
                            BalanceType.MAIN -> it.copy(balanceMain = it.balanceMain - amount)
                            BalanceType.DRIVE -> it.copy(balanceDrive = it.balanceDrive - amount)
                            BalanceType.BANK -> it.copy(balanceBank = it.balanceBank - amount)
                        }
                    }
                    receiver.id -> {
                        when (balanceType) {
                            BalanceType.MAIN -> it.copy(balanceMain = it.balanceMain + amount)
                            BalanceType.DRIVE -> it.copy(balanceDrive = it.balanceDrive + amount)
                            BalanceType.BANK -> it.copy(balanceBank = it.balanceBank + amount)
                        }
                    }
                    else -> it
                }
            }
        }

        _currentUser.update { current ->
            current?.let {
                when (balanceType) {
                    BalanceType.MAIN -> it.copy(balanceMain = it.balanceMain - amount)
                    BalanceType.DRIVE -> it.copy(balanceDrive = it.balanceDrive - amount)
                    BalanceType.BANK -> it.copy(balanceBank = it.balanceBank - amount)
                }
            }
        }

        val trxId = "TRF" + (10000000..99999999).random()
        val tx = TransactionRecord(
            id = UUID.randomUUID().toString(),
            trxId = trxId,
            userId = user.id,
            userName = user.name,
            userPhone = user.phone,
            userRole = user.role,
            type = TransactionType.BALANCE_TRANSFER,
            operator = null,
            recipientNumber = cleanReceiver,
            amount = amount,
            balanceType = balanceType,
            status = OrderStatus.SUCCESSFUL,
            details = "Transfer to ${receiver.name} (${receiver.phone})"
        )

        _transactions.update { listOf(tx) + it }
        return Result.success(tx)
    }

    // Pay Utility Bill or Game Top-up
    fun payBillOrTopup(
        type: TransactionType,
        recipientOrAccount: String,
        amount: Double,
        providerName: String,
        pin: String
    ): Result<TransactionRecord> {
        val user = _currentUser.value ?: return Result.failure(Exception("Not logged in"))
        if (recipientOrAccount.isBlank()) {
            return Result.failure(Exception(if (_isBengali.value) "সঠিক একাউন্ট বা প্লেয়ার আইডি দিন" else "Please enter account or player ID"))
        }

        if (user.pin != pin.trim()) {
            return Result.failure(Exception(if (_isBengali.value) "ভুল পিন কোড" else "Incorrect PIN"))
        }

        if (user.balanceMain < amount) {
            return Result.failure(Exception(if (_isBengali.value) "পর্যাপ্ত মেইন ব্যালেন্স নেই" else "Insufficient main wallet balance"))
        }

        _users.update { list ->
            list.map { if (it.id == user.id) it.copy(balanceMain = it.balanceMain - amount) else it }
        }
        _currentUser.update { it?.copy(balanceMain = it.balanceMain - amount) }

        val prefix = if (type == TransactionType.BILL_PAY) "BIL" else "GMP"
        val trxId = prefix + (10000000..99999999).random()
        val tx = TransactionRecord(
            id = UUID.randomUUID().toString(),
            trxId = trxId,
            userId = user.id,
            userName = user.name,
            userPhone = user.phone,
            userRole = user.role,
            type = type,
            operator = null,
            recipientNumber = recipientOrAccount,
            amount = amount,
            balanceType = BalanceType.MAIN,
            status = OrderStatus.PENDING,
            details = "$providerName payment"
        )

        _transactions.update { listOf(tx) + it }

        repositoryScope.launch {
            delay(1500)
            _transactions.update { list ->
                list.map { if (it.id == tx.id) it.copy(status = OrderStatus.PROCESSING) else it }
            }
            delay(2000)
            _transactions.update { list ->
                list.map { if (it.id == tx.id) it.copy(status = OrderStatus.SUCCESSFUL) else it }
            }
        }

        return Result.success(tx)
    }

    // --- ADMIN PANEL ACTIONS ---

    // Admin approves Add Balance: Credits Dealer wallet & marks successful!
    fun adminApproveAddBalance(requestId: String): Boolean {
        val request = _addBalanceRequests.value.find { it.id == requestId } ?: return false
        if (request.status != OrderStatus.PENDING) return false

        // Credit the targeted dealer wallet
        _users.update { list ->
            list.map { user ->
                if (user.id == request.userId) {
                    when (request.balanceType) {
                        BalanceType.MAIN -> user.copy(balanceMain = user.balanceMain + request.amount)
                        BalanceType.DRIVE -> user.copy(balanceDrive = user.balanceDrive + request.amount)
                        BalanceType.BANK -> user.copy(balanceBank = user.balanceBank + request.amount)
                    }
                } else user
            }
        }

        // Update current user if it's the same
        _currentUser.update { current ->
            if (current?.id == request.userId) {
                when (request.balanceType) {
                    BalanceType.MAIN -> current.copy(balanceMain = current.balanceMain + request.amount)
                    BalanceType.DRIVE -> current.copy(balanceDrive = current.balanceDrive + request.amount)
                    BalanceType.BANK -> current.copy(balanceBank = current.balanceBank + request.amount)
                }
            } else current
        }

        // Update request status
        _addBalanceRequests.update { list ->
            list.map { if (it.id == requestId) it.copy(status = OrderStatus.SUCCESSFUL) else it }
        }

        // Update matching transaction in history
        _transactions.update { list ->
            list.map { if (it.trxId == request.trxId) it.copy(status = OrderStatus.SUCCESSFUL) else it }
        }

        return true
    }

    // Admin rejects Add Balance
    fun adminRejectAddBalance(requestId: String): Boolean {
        val request = _addBalanceRequests.value.find { it.id == requestId } ?: return false
        if (request.status != OrderStatus.PENDING) return false

        _addBalanceRequests.update { list ->
            list.map { if (it.id == requestId) it.copy(status = OrderStatus.FAILED) else it }
        }
        _transactions.update { list ->
            list.map { if (it.trxId == request.trxId) it.copy(status = OrderStatus.FAILED, failureReason = "Invalid TrxID or payment not received") else it }
        }
        return true
    }

    // Admin updates order status (Pending -> Processing -> Successful OR Failed with Auto-Refund!)
    fun adminUpdateOrderStatus(transactionId: String, newStatus: OrderStatus): Boolean {
        val tx = _transactions.value.find { it.id == transactionId } ?: return false

        // If transitioning to FAILED and was not previously failed/refunded, refund dealer wallet!
        if ((newStatus == OrderStatus.FAILED || newStatus == OrderStatus.REFUNDED) &&
            tx.status != OrderStatus.FAILED && tx.status != OrderStatus.REFUNDED
        ) {
            _users.update { list ->
                list.map { user ->
                    if (user.id == tx.userId) {
                        when (tx.balanceType) {
                            BalanceType.MAIN -> user.copy(balanceMain = user.balanceMain + tx.amount)
                            BalanceType.DRIVE -> user.copy(balanceDrive = user.balanceDrive + tx.amount)
                            BalanceType.BANK -> user.copy(balanceBank = user.balanceBank + tx.amount)
                        }
                    } else user
                }
            }

            _currentUser.update { current ->
                if (current?.id == tx.userId) {
                    when (tx.balanceType) {
                        BalanceType.MAIN -> current.copy(balanceMain = current.balanceMain + tx.amount)
                        BalanceType.DRIVE -> current.copy(balanceDrive = current.balanceDrive + tx.amount)
                        BalanceType.BANK -> current.copy(balanceBank = current.balanceBank + tx.amount)
                    }
                } else current
            }
        }

        _transactions.update { list ->
            list.map {
                if (it.id == transactionId) {
                    it.copy(
                        status = newStatus,
                        failureReason = if (newStatus == OrderStatus.FAILED) "Operator gateway rejected or number inactive (Balance refunded)" else null
                    )
                } else it
            }
        }

        return true
    }

    // Admin adds new package
    fun adminAddPackage(pkg: TelecomPackage) {
        _packages.update { listOf(pkg) + it }
    }

    fun adminTogglePackage(pkgId: String) {
        _packages.update { list ->
            list.map { if (it.id == pkgId) it.copy(isActive = !it.isActive) else it }
        }
    }

    // Admin updates notice
    fun adminUpdateNotice(title: String, textEn: String, textBn: String) {
        val newNotice = Notice(
            id = "n_" + System.currentTimeMillis(),
            title = title,
            textEn = textEn,
            textBn = textBn
        )
        _notices.update { listOf(newNotice) + it }
    }

    // Admin updates telecom API configuration
    fun adminUpdateApiConfig(config: TelecomApiConfig) {
        _apiConfig.value = config
    }

    // Admin toggles dealer active/block status
    fun adminToggleUserStatus(userId: String) {
        _users.update { list ->
            list.map { if (it.id == userId) it.copy(isActive = !it.isActive) else it }
        }
    }

    // Compute admin stats
    fun getAdminStats(): AdminLedgerStats {
        val allUsers = _users.value
        val allTx = _transactions.value
        val pendingAdd = _addBalanceRequests.value.count { it.status == OrderStatus.PENDING }
        val pendingOrders = allTx.count { it.status == OrderStatus.PENDING || it.status == OrderStatus.PROCESSING }
        val successful = allTx.count { it.status == OrderStatus.SUCCESSFUL }
        val totalBal = allUsers.sumOf { it.balanceMain + it.balanceDrive + it.balanceBank }
        val todaySales = allTx.filter { it.status == OrderStatus.SUCCESSFUL }.sumOf { it.amount }

        return AdminLedgerStats(
            totalDealers = allUsers.size,
            totalSystemBalance = totalBal,
            todaySalesVolume = todaySales,
            pendingOrdersCount = pendingOrders,
            pendingAddBalanceCount = pendingAdd,
            successfulOrdersCount = successful
        )
    }

    // Preloaded Bangladesh Telecom Package Database
    private fun generateInitialPackages(): List<TelecomPackage> {
        return listOf(
            // GRAMEENPHONE DRIVE PACKAGES
            TelecomPackage(
                id = "gp_d1",
                operator = Operator.GRAMEENPHONE,
                title = "GP 50GB Internet + 1000 Minutes",
                titleBn = "জিপি ৫০ জিবি ইন্টারনেট + ১০০০ মিনিট",
                dataVolume = "50 GB",
                minutes = "1000 Min",
                sms = "100 SMS",
                validity = "30 Days",
                validityBn = "৩০ দিন",
                regularPrice = 998.0,
                offerPrice = 740.0,
                commission = 258.0,
                category = PackageCategory.COMBO,
                packageType = PackageType.DRIVE,
                eligibleDivision = "সমগ্র বাংলাদেশ (All BD)"
            ),
            TelecomPackage(
                id = "gp_d2",
                operator = Operator.GRAMEENPHONE,
                title = "GP 40GB All BD Special",
                titleBn = "জিপি ৪০ জিবি অল বিডি স্পেশাল",
                dataVolume = "40 GB",
                minutes = "0 Min",
                sms = "0 SMS",
                validity = "30 Days",
                validityBn = "৩০ দিন",
                regularPrice = 699.0,
                offerPrice = 520.0,
                commission = 179.0,
                category = PackageCategory.INTERNET,
                packageType = PackageType.DRIVE,
                eligibleDivision = "সমগ্র বাংলাদেশ (All BD)"
            ),
            TelecomPackage(
                id = "gp_d3",
                operator = Operator.GRAMEENPHONE,
                title = "GP 800 Minutes Any Net",
                titleBn = "জিপি ৮০০ মিনিট যেকোনো নাম্বারে",
                dataVolume = "0 GB",
                minutes = "800 Min",
                sms = "0 SMS",
                validity = "30 Days",
                validityBn = "৩০ দিন",
                regularPrice = 599.0,
                offerPrice = 455.0,
                commission = 144.0,
                category = PackageCategory.MINUTES,
                packageType = PackageType.DRIVE,
                eligibleDivision = "ঢাকা, চট্টগ্রাম, রাজশাহী"
            ),
            TelecomPackage(
                id = "gp_r1",
                operator = Operator.GRAMEENPHONE,
                title = "GP 10GB Weekly Booster",
                titleBn = "জিপি ১০ জিবি সাপ্তাহিক বুস্টার",
                dataVolume = "10 GB",
                minutes = "0 Min",
                sms = "0 SMS",
                validity = "7 Days",
                validityBn = "৭ দিন",
                regularPrice = 198.0,
                offerPrice = 179.0,
                commission = 19.0,
                category = PackageCategory.INTERNET,
                packageType = PackageType.REGULAR
            ),

            // ROBI DRIVE PACKAGES
            TelecomPackage(
                id = "rb_d1",
                operator = Operator.ROBI,
                title = "Robi 60GB Internet + 1200 Min",
                titleBn = "রবি ৬০ জিবি + ১২০০ মিনিট ড্রাইভ",
                dataVolume = "60 GB",
                minutes = "1200 Min",
                sms = "150 SMS",
                validity = "30 Days",
                validityBn = "৩০ দিন",
                regularPrice = 1049.0,
                offerPrice = 770.0,
                commission = 279.0,
                category = PackageCategory.COMBO,
                packageType = PackageType.DRIVE,
                eligibleDivision = "সমগ্র বাংলাদেশ (All BD)"
            ),
            TelecomPackage(
                id = "rb_d2",
                operator = Operator.ROBI,
                title = "Robi 45GB Internet All BD",
                titleBn = "রবি ৪৫ জিবি অল বিডি ধামাকা",
                dataVolume = "45 GB",
                minutes = "0 Min",
                sms = "0 SMS",
                validity = "30 Days",
                validityBn = "৩০ দিন",
                regularPrice = 649.0,
                offerPrice = 475.0,
                commission = 174.0,
                category = PackageCategory.INTERNET,
                packageType = PackageType.DRIVE,
                eligibleDivision = "সমগ্র বাংলাদেশ (All BD)"
            ),
            TelecomPackage(
                id = "rb_d3",
                operator = Operator.ROBI,
                title = "Robi 1000 Minutes Bundle",
                titleBn = "রবি ১০০০ মিনিট যেকোনো লোকাল",
                dataVolume = "0 GB",
                minutes = "1000 Min",
                sms = "50 SMS",
                validity = "30 Days",
                validityBn = "৩০ দিন",
                regularPrice = 698.0,
                offerPrice = 520.0,
                commission = 178.0,
                category = PackageCategory.MINUTES,
                packageType = PackageType.DRIVE,
                eligibleDivision = "সমগ্র বাংলাদেশ"
            ),
            TelecomPackage(
                id = "rb_r1",
                operator = Operator.ROBI,
                title = "Robi 15GB Internet Monthly",
                titleBn = "রবি ১৫ জিবি রেগুলার প্যাক",
                dataVolume = "15 GB",
                minutes = "0 Min",
                sms = "0 SMS",
                validity = "30 Days",
                validityBn = "৩০ দিন",
                regularPrice = 399.0,
                offerPrice = 370.0,
                commission = 29.0,
                category = PackageCategory.INTERNET,
                packageType = PackageType.REGULAR
            ),

            // BANGLALINK DRIVE PACKAGES
            TelecomPackage(
                id = "bl_d1",
                operator = Operator.BANGLALINK,
                title = "BL 50GB + 900 Minutes Combo",
                titleBn = "বাংলালিংক ৫০ জিবি + ৯০০ মিনিট মেগা ড্রাইভ",
                dataVolume = "50 GB",
                minutes = "900 Min",
                sms = "100 SMS",
                validity = "30 Days",
                validityBn = "৩০ দিন",
                regularPrice = 899.0,
                offerPrice = 640.0,
                commission = 259.0,
                category = PackageCategory.COMBO,
                packageType = PackageType.DRIVE,
                eligibleDivision = "সমগ্র বাংলাদেশ (All BD)"
            ),
            TelecomPackage(
                id = "bl_d2",
                operator = Operator.BANGLALINK,
                title = "BL 35GB Internet Super Pack",
                titleBn = "বাংলালিংক ৩৫ জিবি সুপার ইন্টারনেট",
                dataVolume = "35 GB",
                minutes = "0 Min",
                sms = "0 SMS",
                validity = "30 Days",
                validityBn = "৩০ দিন",
                regularPrice = 549.0,
                offerPrice = 395.0,
                commission = 154.0,
                category = PackageCategory.INTERNET,
                packageType = PackageType.DRIVE,
                eligibleDivision = "সমগ্র বাংলাদেশ (All BD)"
            ),
            TelecomPackage(
                id = "bl_d3",
                operator = Operator.BANGLALINK,
                title = "BL 750 Minutes Voice Pack",
                titleBn = "বাংলালিংক ৭৫০ মিনিট ভয়েস প্যাক",
                dataVolume = "0 GB",
                minutes = "750 Min",
                sms = "0 SMS",
                validity = "30 Days",
                validityBn = "৩০ দিন",
                regularPrice = 509.0,
                offerPrice = 390.0,
                commission = 119.0,
                category = PackageCategory.MINUTES,
                packageType = PackageType.DRIVE,
                eligibleDivision = "সমগ্র বাংলাদেশ"
            ),

            // AIRTEL DRIVE PACKAGES
            TelecomPackage(
                id = "at_d1",
                operator = Operator.AIRTEL,
                title = "Airtel 40GB + 800 Minutes",
                titleBn = "এয়ারটেল ৪০ জিবি + ৮০০ মিনিট ড্রাইভ",
                dataVolume = "40 GB",
                minutes = "800 Min",
                sms = "100 SMS",
                validity = "30 Days",
                validityBn = "৩০ দিন",
                regularPrice = 799.0,
                offerPrice = 575.0,
                commission = 224.0,
                category = PackageCategory.COMBO,
                packageType = PackageType.DRIVE,
                eligibleDivision = "সমগ্র বাংলাদেশ (All BD)"
            ),
            TelecomPackage(
                id = "at_d2",
                operator = Operator.AIRTEL,
                title = "Airtel 30GB All BD Offer",
                titleBn = "এয়ারটেল ৩০ জিবি অল বিডি ড্রাইভ",
                dataVolume = "30 GB",
                minutes = "0 Min",
                sms = "0 SMS",
                validity = "30 Days",
                validityBn = "৩০ দিন",
                regularPrice = 499.0,
                offerPrice = 360.0,
                commission = 139.0,
                category = PackageCategory.INTERNET,
                packageType = PackageType.DRIVE,
                eligibleDivision = "সমগ্র বাংলাদেশ"
            ),

            // TELETALK PACKAGES
            TelecomPackage(
                id = "tt_d1",
                operator = Operator.TELETALK,
                title = "Teletalk 30GB Bornomala Pack",
                titleBn = "টেলিটক ৩০ জিবি বর্ণমালা স্পেশাল",
                dataVolume = "30 GB",
                minutes = "300 Min",
                sms = "100 SMS",
                validity = "30 Days",
                validityBn = "৩০ দিন",
                regularPrice = 450.0,
                offerPrice = 330.0,
                commission = 120.0,
                category = PackageCategory.COMBO,
                packageType = PackageType.DRIVE,
                eligibleDivision = "সমগ্র বাংলাদেশ"
            ),
            TelecomPackage(
                id = "tt_r1",
                operator = Operator.TELETALK,
                title = "Teletalk 15GB Oporajita Monthly",
                titleBn = "টেলিটক ১৫ জিবি অপরাজিতা প্যাক",
                dataVolume = "15 GB",
                minutes = "0 Min",
                sms = "0 SMS",
                validity = "30 Days",
                validityBn = "৩০ দিন",
                regularPrice = 249.0,
                offerPrice = 220.0,
                commission = 29.0,
                category = PackageCategory.INTERNET,
                packageType = PackageType.REGULAR
            )
        )
    }

    private fun generateInitialTransactions(): List<TransactionRecord> {
        return listOf(
            TransactionRecord(
                id = "tx1",
                trxId = "MTX98102931",
                userId = "dealer_01",
                userName = "Rana Telecom Service",
                userPhone = "01711223344",
                userRole = UserRole.DEALER,
                type = TransactionType.RECHARGE,
                operator = Operator.GRAMEENPHONE,
                recipientNumber = "01799887766",
                amount = 200.0,
                commissionEarned = 5.2,
                balanceType = BalanceType.MAIN,
                status = OrderStatus.SUCCESSFUL,
                details = "Prepaid Flexiload (GP)",
                timestamp = System.currentTimeMillis() - 15 * 60 * 1000
            ),
            TransactionRecord(
                id = "tx2",
                trxId = "PKG88102394",
                userId = "dealer_01",
                userName = "Rana Telecom Service",
                userPhone = "01711223344",
                userRole = UserRole.DEALER,
                type = TransactionType.DRIVE_PURCHASE,
                operator = Operator.ROBI,
                recipientNumber = "01822334455",
                amount = 770.0,
                commissionEarned = 279.0,
                balanceType = BalanceType.DRIVE,
                status = OrderStatus.SUCCESSFUL,
                details = "Robi 60GB Internet + 1200 Min - 30 Days",
                timestamp = System.currentTimeMillis() - 45 * 60 * 1000
            ),
            TransactionRecord(
                id = "tx3",
                trxId = "BLX3329104",
                userId = "dealer_01",
                userName = "Rana Telecom Service",
                userPhone = "01711223344",
                userRole = UserRole.DEALER,
                type = TransactionType.RECHARGE,
                operator = Operator.BANGLALINK,
                recipientNumber = "01944556677",
                amount = 50.0,
                commissionEarned = 1.3,
                balanceType = BalanceType.MAIN,
                status = OrderStatus.PROCESSING,
                details = "Prepaid Flexiload (Banglalink)",
                timestamp = System.currentTimeMillis() - 5 * 60 * 1000
            ),
            TransactionRecord(
                id = "tx4",
                trxId = "ATX4491023",
                userId = "retailer_01",
                userName = "Sujon Store",
                userPhone = "01855667788",
                userRole = UserRole.RETAILER,
                type = TransactionType.RECHARGE,
                operator = Operator.AIRTEL,
                recipientNumber = "01688776655",
                amount = 100.0,
                commissionEarned = 2.4,
                balanceType = BalanceType.MAIN,
                status = OrderStatus.PENDING,
                details = "Prepaid Flexiload (Airtel)",
                timestamp = System.currentTimeMillis() - 2 * 60 * 1000
            )
        )
    }

    private fun generateInitialAddBalanceRequests(): List<AddBalanceRequest> {
        return listOf(
            AddBalanceRequest(
                id = "abr_1",
                userId = "dealer_01",
                userName = "Rana Telecom Service",
                userPhone = "01711223344",
                method = PaymentMethod.BKASH,
                senderNumber = "01711223344",
                trxId = "BKH92019284",
                amount = 1500.0,
                balanceType = BalanceType.DRIVE,
                status = OrderStatus.PENDING,
                requestTime = System.currentTimeMillis() - 20 * 60 * 1000,
                note = "Sent to bKash Merchant"
            ),
            AddBalanceRequest(
                id = "abr_2",
                userId = "retailer_01",
                userName = "Sujon Store",
                userPhone = "01855667788",
                method = PaymentMethod.NAGAD,
                senderNumber = "01855667788",
                trxId = "NGD88291038",
                amount = 500.0,
                balanceType = BalanceType.MAIN,
                status = OrderStatus.SUCCESSFUL,
                requestTime = System.currentTimeMillis() - 2 * 3600 * 1000,
                note = "Approved"
            )
        )
    }
}
